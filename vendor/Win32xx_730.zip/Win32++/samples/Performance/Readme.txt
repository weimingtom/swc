Performance Example
===================
This project can be used to measure the speed of the message handling of 
Win32++. The user is asked to specify the number of test windows required, 
and the number of test messages sent.


Features demonstrated in this example
=====================================
* Use of a dialog to input data
* Creating multiple windows
* Using TRACE to display debug output
