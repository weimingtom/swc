//////////////////////////////////////////////
// resource.h

//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Performance.rc
//

// include the Resource IDs defined by Win32++
#include "default_resource.h"

#define IDC_STATIC                      -1
#define IDD_DIALOG1                     101
#define IDC_WINDOWS                     1001
#define IDC_MESSAGES                    1002
#define IDC_BUTTON1                     1004
#define IDC_BUTTON2                     1005

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
