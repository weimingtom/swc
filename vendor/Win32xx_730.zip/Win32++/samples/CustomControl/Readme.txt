Custom Control Example
==================
This is sample demonstrates how to build a custom control and display it
in a dialog. The custom control is created from CWebBrowser.
  

Features demonstrated in this example
=====================================
* Registering a custom control.
* Specifying the custom control in resource.rc.
* Using CWebBrowser in a custom control.
* Automatic resizing of the custom control when the dialog is resized
  