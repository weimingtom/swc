DialogTab Example
==================
This dialog features a Tab control in the main dialg. The tab control
then displays other simple dialogs. 
  
Note that property sheets provide an alternative to dialogs with a tab control.
Refer to the PropertySheet example for a demonstration of property sheets. 


Features demonstrated in this example
=====================================
* Using a dialog as an application.
* Use of AttachDlgItem to attach a dialog control to a CWnd.
* Use of OnMessageReflect to handle notifications in the object that 
   generated them.
* Using a Tab control within a dialog
* Using dialogs within a tab control