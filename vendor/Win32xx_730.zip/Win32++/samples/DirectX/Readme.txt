DirectX Example
==================
This project displays a moving DirectX picture in a simple window. The code
in this example is based on DirectX version 9. 

Additional software is required to run this example.
For MS compilers you will need the DirectX SDK v9
For Dev-C++ you will need the DirecX v9.0c DevPak

Microsoft makes the the DirectX Software Development Kit available for download
without charge.


Features demonstrated in this example
=====================================
* Displaying a moving DirectX picture in a view window.  
* Putting a view window in a separate thread.
* Adding a view window from a separate threat to a frame.
