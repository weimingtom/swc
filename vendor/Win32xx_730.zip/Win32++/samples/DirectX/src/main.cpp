///////////////////////////////////////
// main.cpp

#include "stdafx.h"
#include "DXApp.h"


int APIENTRY WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    // Start Win32++
    CDXApp MyApp;

	// Run the application
	return MyApp.Run();
}
