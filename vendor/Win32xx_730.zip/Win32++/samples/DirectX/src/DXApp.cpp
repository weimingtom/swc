//////////////////////////////////////////////
// DXApp.cpp

#include "stdafx.h"
#include "DXApp.h"


CDXApp::CDXApp()
{
}

BOOL CDXApp::InitInstance()
{
	//Create the Window
	m_Frame.Create();

	return TRUE;
}

