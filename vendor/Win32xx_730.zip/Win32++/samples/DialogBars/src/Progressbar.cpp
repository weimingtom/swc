//////////////////////////////////////////////
// MyProgressBar.cpp

#include "stdafx.h"
#include "ProgressBar.h"
#include "DialogApp.h"

void CMyProgressBar::SetProgress(int nPos)
{
	// Set the progress bar position
	SetPos(nPos);
}

