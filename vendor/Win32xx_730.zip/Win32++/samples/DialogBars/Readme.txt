DialogBars Example
==================
This program displays a modal dialog containing a slider control, a Scrollbar
control and a progressbar control. These controls are attached to CWnd objects.
 

Features demonstrated in this example
=====================================
* Using a dialog as an application.
* Using a slider, scrollbar and progressbar control in a dialog. 
* Use of AttachDlgItem to attach a dialog control to a CWnd.
* Use of OnMessageReflect to handle notifications in the object that 
   generated them. 