Notepad Example
===============
This project demonstrates how to use a Rich Edit control as a simple text 
editor.


Features demonstrated in this example
=====================================
* Use of CFrame to display the window frame
* Using a Rich edit control in the view window (ver 2.0 for unicode support)
* File open and file save using stream callbacks
* Copy and paste
* File drag and drop
* Text file printing