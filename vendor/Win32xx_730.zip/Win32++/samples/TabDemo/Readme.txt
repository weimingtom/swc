TabDemo Example
===============
This project demonstrates how to use the CTab control within a frame.

Features demonstrated in this example
=====================================
* Use of CFrame to display the window frame
* Toolbar configuration
* Displaying tabs at the top or bottom of the control
* How to Display/Hide the tab close and tab list buttons

