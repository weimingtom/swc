//////////////////////////////////////////////////
// TaskDialogApp.h

#ifndef TASKDIALOGAPP_H
#define TASKDIALOGAPP_H


// Declaration of the CTaskDialogApp class
class CTaskDialogApp : public CWinApp
{
public:
	CTaskDialogApp();
	virtual ~CTaskDialogApp();
	virtual BOOL InitInstance();

private:
//	CTaskDialog m_TaskDialog;
};



#endif // define TASKDIALOGAPP_H

