// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#ifndef STDAFX_H
#define STDAFX_H

// Predefinitions for windows.h go here
//#define WIN32_LEAN_AND_MEAN	// Exclude rarely-used stuff from Windows headers
#include "targetver.h"			// Set the supported window features

#include <wincore.h>
#include <dialog.h>


#endif // define STDAFX_H
