Picture Example
===============
This example uses the IPicture interface to load and display a graphic 
image.


Features demonstrated in this example
=====================================
* Use of CFrame to display the window frame
* Use of the IPicture interface to load and render the picture
* Automatic resizing of the frame to accomodate the picture size when loaded
* Use of scroll bars
* Use of file open dialogs
* Implementation of a Most Recently Used (MRU) List in the File menu.
