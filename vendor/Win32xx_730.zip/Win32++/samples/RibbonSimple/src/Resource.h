//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//


// include the Resource IDs defined by Win32++
#include "default_resource.h"

#define IDS_APP_TITLE           100
#define IDI_SIMPLERIBBON        101
#define IDI_SMALL               102
#define IDC_SIMPLERIBBON        103

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           130
#endif
#endif
