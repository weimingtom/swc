//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//

// include the Resource IDs defined by Win32++
#include "default_resource.h"

// Server Dialog
#define IDD_SERVER                              110
#define IDC_EDIT_STATUS                         111
#define IDC_EDIT_PORT                           112
#define IDC_EDIT_SEND                           113
#define IDC_EDIT_RECEIVE                        114
#define IDC_BUTTON_START                        115
#define IDC_BUTTON_SEND                         116
#define IDC_RADIO_TCP                           117
#define IDC_RADIO_UDP                           118
#define IDC_RADIO_IPV4                          119
#define IDC_RADIO_IPV6                          120
#define IDC_IPADDRESS                           121
#define IDC_EDIT_IPV6ADDRESS                    122
#define IDC_RADIO_GROUP                         124

// Chat Dialog
#define IDD_CHAT                                140
#define IDC_EDIT_RECEIVE2                       141
#define IDC_EDIT_SEND2                          142
#define IDC_BUTTON_SEND2                        143


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        149
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           150
#endif
#endif


