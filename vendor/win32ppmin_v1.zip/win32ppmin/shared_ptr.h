#pragma once

	template <class T1>
	class Shared_Ptr
	{
	public:
		Shared_Ptr() : m_ptr(NULL), m_count(NULL) { }
		Shared_Ptr(T1 * p) : m_ptr(p), m_count(NULL)
		{
			try
			{
				if (m_ptr) m_count = new long(0);
                inc_ref();
			}
			// catch the unlikely event of 'new long(0)' throwing an exception
			catch (const std::bad_alloc&)
			{
				delete m_ptr;
				throw;
			}
		}
		Shared_Ptr(const Shared_Ptr& rhs) : m_ptr(rhs.m_ptr), m_count(rhs.m_count) { inc_ref(); }
		~Shared_Ptr()
		{
			if(m_count && 0 == dec_ref())
			{
				// Note: This code doesn't handle a pointer to an array.
				//  We would need delete[] m_ptr to handle that.
				delete m_ptr;
				delete m_count;
			}
		}

		T1* get() const { return m_ptr; }
		long use_count() const { return m_count? *m_count : 0; }
		bool unique() const { return (m_count && (*m_count == 1)); }

		void swap(Shared_Ptr& rhs)
		{
		   std::swap(m_ptr, rhs.m_ptr);
		   std::swap(m_count, rhs.m_count);
		}

		Shared_Ptr& operator=(const Shared_Ptr& rhs)
		{
			 Shared_Ptr tmp(rhs);
			 this->swap(tmp);
			 return *this;
		}

		T1* operator->() const
		{
			assert(m_ptr);
			return m_ptr;
		}

		T1& operator*() const
		{
			assert (m_ptr);
			return *m_ptr;
		}

		bool operator== (const Shared_Ptr& rhs) const
		{
			return ( *m_ptr == *rhs.m_ptr);
		}

		bool operator!= (const Shared_Ptr& rhs) const
		{
			return ( *m_ptr != *rhs.m_ptr);
		}

		bool operator< (const Shared_Ptr& rhs) const
		{
			return ( *m_ptr < *rhs.m_ptr );
		}

		bool operator> (const Shared_Ptr& rhs) const
		{
			return ( *m_ptr > *rhs.m_ptr );
		}

	private:
		void inc_ref()
		{
			if(m_count)
				InterlockedIncrement(m_count);
		}

		int  dec_ref()
		{
			assert (m_count);
			return InterlockedDecrement(m_count);
		}

		T1* m_ptr;
		long* m_count;
	};
