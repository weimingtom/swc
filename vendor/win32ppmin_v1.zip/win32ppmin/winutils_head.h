#pragma once

// define useful macros from WindowsX.h
#ifndef GET_X_LPARAM
  #define GET_X_LPARAM(lp)  ((int)(short)LOWORD(lp))
#endif
#ifndef GET_Y_LPARAM
  #define GET_Y_LPARAM(lp)  ((int)(short)HIWORD(lp))
#endif

// Define our own MIN and MAX macros
// this avoids inconsistencies with Dev-C++ and other compilers, and
// avoids conflicts between typical min/max macros and std::min/std::max
#define MAX(a,b)            (((a) > (b)) ? (a) : (b))
#define MIN(a,b)            (((a) < (b)) ? (a) : (b))


	// Forward declarations
	class CPoint;
	class CRect;
	CWinApp* GetApp();
	void TRACE(LPCTSTR str);


	/////////////////////////////////////////
	// Definition of the CSize class
	// This class can be used to replace the SIZE structure
	class CSize : public SIZE
	{
	public:
		CSize()								{ cx = 0; cy = 0; }
		CSize(int CX, int CY)				{ cx = CX; cy = CY; }
		CSize(SIZE sz)						{ cx = sz.cx; cy = sz.cy; }
		CSize(POINT pt)						{ cx = pt.x;  cy = pt.y; }
		CSize(DWORD dw)						{ cx = (short)LOWORD(dw); cy = (short)HIWORD(dw); }
		void SetSize(int CX, int CY)		{ cx = CX; cy = CY; }

		// Operators
		operator LPSIZE()					{ return this; }
		BOOL operator == (SIZE sz) const	{ return (cx == sz.cx && cy == sz.cy); }
		BOOL operator != (SIZE sz) const	{ return (cx != sz.cx || cy != sz.cy); }
		void operator += (SIZE sz)			{ cx += sz.cx; cy += sz.cy; }
		void operator -= (SIZE sz)			{ cx -= sz.cx; cy -= sz.cy; }

		// Operators returning CSize
		CSize operator - () const			{ return CSize (-cx, -cy); }
		CSize operator + (SIZE sz) const	{ return CSize (cx + sz.cx, cy + sz.cy); }
		CSize operator - (SIZE sz) const	{ return CSize (cx - sz.cx, cy - sz.cy); }

		// Operators returning CPoint
		CPoint operator + (POINT point) const;
		CPoint operator - (POINT point) const;

		// Operators returning CRect
		CRect operator + (RECT rc) const;
		CRect operator - (RECT rc) const;
	};


	/////////////////////////////////////////
	// Definition of the CPoint class
	// This class can be used to replace the POINT structure
	class CPoint : public POINT
	{
	public:
		CPoint()							{ x = 0; y = 0; }
		CPoint(int X, int Y)				{ x = X; y = Y; }
		CPoint(POINT pt)					{ x = pt.x ; y = pt.y; }
		CPoint(POINTS pts)					{ x = pts.x; y = pts.y; }
		CPoint(SIZE sz)						{ x = sz.cx; y = sz.cy; }
		CPoint(DWORD dw)					{ x = (short) LOWORD(dw); y = (short) HIWORD(dw); }

		void Offset(int dx, int dy)			{ x += dx; y += dy; }
		void Offset(POINT pt)				{ x += pt.x; y += pt.y; }
		void Offset(SIZE sz)				{ x += sz.cx; y += sz.cy; }
		void SetPoint(int X, int Y)			{ x = X; y = Y; }

		// Operators
		operator LPPOINT()					{ return this; }
		BOOL operator == (POINT pt) const	{ return ((x == pt.x) && (y == pt.y)); }
		BOOL operator != (POINT pt) const	{ return ((x != pt.x) || (y != pt.y)); }
		void operator += (SIZE sz)			{ x += sz.cx; y += sz.cy; }
		void operator -= (SIZE sz)			{ x -= sz.cx; y -= sz.cy; }
		void operator += (POINT pt)			{ x += pt.x; y += pt.y; }
		void operator -= (POINT pt)			{ x -= pt.x; y -= pt.y; }

		// Operators returning CPoint
		CPoint operator - () const			{ return CPoint(-x, -y); }
		CPoint operator + (SIZE sz) const	{ return CPoint(x + sz.cx, y + sz.cy); }
		CPoint operator - (SIZE sz) const	{ return CPoint(x - sz.cx, y - sz.cy); }
		CPoint operator + (POINT pt) const	{ return CPoint(x + pt.x, y + pt.y); }
		CPoint operator - (POINT pt) const	{ return CPoint(x - pt.x, y - pt.y); }

		// Operators returning CRect
		CRect operator + (RECT rc) const;
		CRect operator - (RECT rc) const;
	};


	/////////////////////////////////////////
	// Definition of the CRect class
	// This class can be used to replace the RECT structure.
	class CRect : public RECT
	{
	public:
		CRect()										{ left = top = right = bottom = 0; }
		CRect(int l, int t, int r, int b)			{ left = l; top = t; right = r; bottom = b; }
		CRect(RECT rc)								{ left = rc.left; top = rc.top; right = rc.right; bottom = rc.bottom; }
		CRect(POINT pt, SIZE sz)					{ right = (left = pt.x) + sz.cx; bottom = (top = pt.y) + sz.cy; }
		CRect(POINT topLeft, POINT bottomRight)		{ left = topLeft.x; top = topLeft.y; right = bottomRight.x; bottom = bottomRight.y; }

		BOOL CopyRect(RECT rc)						{ return ::CopyRect(this, &rc); }
		BOOL DeflateRect(int x, int y)				{ return ::InflateRect(this, -x, -y); }
		BOOL DeflateRect(SIZE size)					{ return ::InflateRect(this, -size.cx, -size.cy); }
		BOOL DeflateRect(RECT rc)					{ return ::InflateRect(this, rc.left - rc.right, rc.top - rc.bottom); }
		BOOL DeflateRect(int l, int t, int r, int b){ return ::InflateRect(this, l - r, t - b); }
		BOOL EqualRect(RECT rc) const				{ return ::EqualRect(&rc, this); }
		BOOL InflateRect(int dx, int dy)			{ return ::InflateRect(this, dx, dy); }
		BOOL InflateRect(SIZE sz)					{ return ::InflateRect(this, sz.cx, sz.cy); }
		BOOL InflateRect(RECT rc)					{ return ::InflateRect(this, rc.right - rc.left, rc.bottom - rc.top); }
		BOOL InflateRect(int l, int t, int r, int b){ return ::InflateRect(this, r - l, b - t); }
		BOOL IntersectRect(RECT rc1, RECT rc2)		{ return ::IntersectRect(this, &rc1, &rc2); }
		BOOL IsRectEmpty() const					{ return ::IsRectEmpty(this);}
		BOOL IsRectNull() const						{ return (left == 0 && right == 0 && top == 0 && bottom == 0); }
		CRect MulDiv(int nMult, int nDiv) const		{ return CRect ((left * nMult) / nDiv, (top * nMult) / nDiv,
														(right * nMult) / nDiv, (bottom * nMult) / nDiv); }
		void NormalizeRect()						{ int nTemp; if (left > right) { nTemp = left; left = right; right = nTemp; }
														if (top > bottom) { nTemp = top; top = bottom; bottom = nTemp; } }
		BOOL OffsetRect(int dx, int dy)				{ return ::OffsetRect(this, dx, dy); }
		BOOL OffsetRect(POINT pt)					{ return ::OffsetRect(this, pt.x, pt.y); }
		BOOL OffsetRect(SIZE size)					{ return ::OffsetRect(this, size.cx, size.cy); }
		BOOL PtInRect(POINT pt) const				{ return ::PtInRect(this, pt); }
		BOOL SetRect(int l, int t, int r, int b)	{ return ::SetRect(this, l, t, r, b); }
		BOOL SetRect(POINT TopLeft, POINT BtmRight)	{ return ::SetRect(this, TopLeft.x, TopLeft.y, BtmRight.x, BtmRight.y); }
		BOOL SetRectEmpty()							{ return ::SetRectEmpty(this); }
		BOOL SubtractRect(RECT rc1, RECT rc2)		{ return ::SubtractRect(this, &rc1, &rc2); }
		BOOL UnionRect(RECT rc1, RECT rc2)			{ return ::UnionRect(this, &rc1, &rc2); }

		// Reposition rectangle
		void MoveToX (int x)						{ right = Width() + x; left = x; }
		void MoveToY (int y)						{ bottom = Height() + y; top = y; }
		void MoveToXY (int x, int y)				{ MoveToX(x); MoveToY(y); }
		void MoveToXY (POINT pt)					{ MoveToX (pt.x); MoveToY (pt.y); }

		// Attributes
		int Height() const							{ return bottom - top; }
		int Width() const							{ return right - left; }
		CSize Size() const							{ return CSize(Width(), Height()); }
		CPoint CenterPoint() const					{ return CPoint((left + right) / 2, (top + bottom) / 2); }
		CPoint TopLeft() const						{ return CPoint(left, top); }
		CPoint BottomRight() const					{ return CPoint(right, bottom); }

		// operators
		operator LPRECT()							{ return this; }
		BOOL operator == (RECT rc) const			{ return ::EqualRect(this, &rc); }
		BOOL operator != (RECT rc) const			{ return !::EqualRect(this, &rc); }
		void operator += (POINT pt)					{ ::OffsetRect(this, pt.x, pt.y); }
		void operator += (SIZE size)				{ ::OffsetRect(this, size.cx, size.cy); }
		void operator += (RECT rc)					{ ::InflateRect(this, rc.right - rc.left, rc.bottom - rc.top); }
		void operator -= (RECT rc)					{ ::InflateRect(this, rc.left - rc.right, rc.top - rc.bottom); }
		void operator -= (POINT pt)					{ ::OffsetRect(this, -pt.x, -pt.y); }
		void operator -= (SIZE sz)					{ ::OffsetRect(this, -sz.cx, -sz.cy); }
		void operator &= (RECT rc)					{ ::IntersectRect(this, this, &rc); }
		void operator |= (RECT rc)					{ ::UnionRect(this, this, &rc); }

		// Operators returning CRect
		CRect operator + (POINT pt) const			{ CRect rc(*this); ::OffsetRect(&rc, pt.x, pt.y); return rc; }
		CRect operator - (POINT pt) const			{ CRect rc(*this); ::OffsetRect(&rc, -pt.x, -pt.y); return rc; }
		CRect operator + (SIZE sz) const			{ CRect rc(*this); ::OffsetRect(&rc, sz.cx, sz.cy); return rc; }
		CRect operator - (SIZE sz) const			{ CRect rc(*this); ::OffsetRect(&rc, -sz.cx, -sz.cy); return rc; }
		CRect operator + (RECT rc) const			{ CRect rc1(*this); rc1.InflateRect(rc); return rc1; }
		CRect operator - (RECT rc) const			{ CRect rc1(*this); rc1.DeflateRect(rc); return rc1; }
		CRect operator & (RECT rc) const			{ CRect rc1; ::IntersectRect(&rc1, this, &rc); return rc1; }
		CRect operator | (RECT rc) const			{ CRect rc1; ::UnionRect(&rc1, this, &rc); return rc1; }
	};

	// CSize member function definitions
	inline CPoint CSize::operator + (POINT pt) const	{ return CPoint(pt) + *this; }
	inline CPoint CSize::operator - (POINT pt) const	{ return CPoint(pt) - *this; }
	inline CRect CSize::operator + (RECT rc) const		{ return CRect(rc) + *this; }
	inline CRect CSize::operator - (RECT rc) const		{ return CRect(rc) - *this; }

	// CPoint member function definitions
	inline CRect CPoint::operator + (RECT rc) const		{ return CRect(rc) + *this; }
	inline CRect CPoint::operator - (RECT rc) const		{ return CRect(rc) - *this; }
