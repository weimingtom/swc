#include "CWinException.h"

CWinException::CWinException(LPCTSTR pszText) throw () : m_Error(::GetLastError()), m_pszText(pszText)
{
	memset(m_szErrorString, 0, MAX_STRING_SIZE * sizeof(TCHAR));

	if (m_Error != 0)
	{
		DWORD dwFlags = FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS;
		::FormatMessage(dwFlags, NULL, m_Error, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), m_szErrorString, MAX_STRING_SIZE-1, NULL);
	}
}

DWORD CWinException::GetError() const throw ()
{
	return m_Error;
}

LPCTSTR CWinException::GetErrorString() const throw ()
{
	return m_szErrorString;
}

const char * CWinException::what() const throw ()
{
	// Sends the last error string to the debugger (typically displayed in the IDE's output window).
	::OutputDebugString(m_szErrorString);
	return "CWinException thrown";
}
