#pragma once

#include "wincore_head.h"
#include "winutils_head.h"
//#include "winutils.h"
#include "cstring.h"

class CWnd
{
friend class CMDIChild;
friend class CDialog;
friend class CPropertyPage;
friend class CTaskDialog;
friend class CWinApp;

public:
	CWnd();				// Constructor
	CWnd(HWND hWnd)		// Constructor
	{
		if (hWnd == HWND_TOP || hWnd == HWND_TOPMOST || hWnd == HWND_BOTTOM || hWnd == HWND_NOTOPMOST)
		{
			m_hWnd = hWnd;
		}
		else
			Attach(hWnd);
	}
	virtual ~CWnd();	// Destructor

	// These virtual functions can be overridden
	virtual BOOL Attach(HWND hWnd);
	virtual BOOL AttachDlgItem(UINT nID, CWnd* pParent);
	virtual void CenterWindow() const;
	virtual HWND Create(CWnd* pParent = NULL);
	virtual HWND CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, int x, int y, int nWidth, int nHeight, CWnd* pParent, CMenu* pMenu, LPVOID lpParam = NULL);
	virtual HWND CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rc, CWnd* pParent, CMenu* pMenu, LPVOID lpParam = NULL);
	virtual void Destroy();
	virtual HWND Detach();
	virtual HICON SetIconLarge(int nIcon);
	virtual HICON SetIconSmall(int nIcon);

	// Attributes
	HWND GetHwnd() const				{ return m_hWnd; }
	WNDPROC GetPrevWindowProc() const	{ return m_PrevWindowProc; }

	// Wrappers for Win32 API functions
	// These functions aren't virtual, and shouldn't be overridden
	CDC*  BeginPaint(PAINTSTRUCT& ps) const;
	BOOL  BringWindowToTop() const;
	LRESULT CallWindowProc(WNDPROC lpPrevWndFunc, UINT Msg, WPARAM wParam, LPARAM lParam) const;
	BOOL  CheckDlgButton(int nIDButton, UINT uCheck) const;
	BOOL  CheckRadioButton(int nIDFirstButton, int nIDLastButton, int nIDCheckButton) const;
	CWnd* ChildWindowFromPoint(POINT pt) const;
	BOOL  ClientToScreen(POINT& pt) const;
	BOOL  ClientToScreen(RECT& rc) const;
	LRESULT DefWindowProc(UINT uMsg, WPARAM wParam, LPARAM lParam) const;
	HDWP  DeferWindowPos(HDWP hWinPosInfo, HWND hWndInsertAfter, int x, int y, int cx, int cy, UINT uFlags) const;
	HDWP  DeferWindowPos(HDWP hWinPosInfo, HWND hWndInsertAfter, const RECT& rc, UINT uFlags) const;
	BOOL  DrawMenuBar() const;
	BOOL  EnableWindow(BOOL bEnable = TRUE) const;
	BOOL  EndPaint(PAINTSTRUCT& ps) const;
	CWnd* GetActiveWindow() const;
	CWnd* GetAncestor(UINT gaFlag = 3 /*= GA_ROOTOWNER*/) const;
	CWnd* GetCapture() const;
	ULONG_PTR GetClassLongPtr(int nIndex) const;
	CString GetClassName() const;
	CRect GetClientRect() const;
	CDC*  GetDC() const;
	CDC*  GetDCEx(HRGN hrgnClip, DWORD flags) const;
	CWnd* GetDesktopWindow() const;
	CWnd* GetDlgItem(int nIDDlgItem) const;
	UINT  GetDlgItemInt(int nIDDlgItem, BOOL* lpTranslated, BOOL bSigned) const;
	CString GetDlgItemText(int nIDDlgItem) const;
	CWnd* GetFocus() const;
	CFont* GetFont() const;
	HICON GetIcon(BOOL bBigIcon) const;
	CWnd* GetNextDlgGroupItem(CWnd* pCtl, BOOL bPrevious) const;
	CWnd* GetNextDlgTabItem(CWnd* pCtl, BOOL bPrevious) const;
	CWnd* GetParent() const;
	BOOL  GetScrollInfo(int fnBar, SCROLLINFO& si) const;
	CRect GetUpdateRect(BOOL bErase) const;
	int GetUpdateRgn(CRgn* pRgn, BOOL bErase) const;
	CWnd* GetWindow(UINT uCmd) const;
	CDC*  GetWindowDC() const;
	LONG_PTR GetWindowLongPtr(int nIndex) const;
	CRect GetWindowRect() const;
	CString GetWindowText() const;
	int   GetWindowTextLength() const;
	void  Invalidate(BOOL bErase = TRUE) const;
	BOOL  InvalidateRect(LPCRECT lpRect, BOOL bErase = TRUE) const;
	BOOL  InvalidateRgn(CRgn* pRgn, BOOL bErase = TRUE) const;
	BOOL  IsChild(CWnd* pChild) const;
	BOOL  IsDialogMessage(LPMSG lpMsg) const;
	UINT  IsDlgButtonChecked(int nIDButton) const;
	BOOL  IsWindow() const;
	BOOL  IsWindowEnabled() const;
	BOOL  IsWindowVisible() const;
	BOOL  KillTimer(UINT_PTR uIDEvent) const;
	int   MessageBox(LPCTSTR lpText, LPCTSTR lpCaption, UINT uType) const;
	void  MapWindowPoints(CWnd* pWndTo, POINT& pt) const;
	void  MapWindowPoints(CWnd* pWndTo, RECT& rc) const;
	void  MapWindowPoints(CWnd* pWndTo, LPPOINT ptArray, UINT nCount) const;
	BOOL  MoveWindow(int x, int y, int nWidth, int nHeight, BOOL bRepaint = TRUE) const;
	BOOL  MoveWindow(const RECT& rc, BOOL bRepaint = TRUE) const;
	BOOL  PostMessage(UINT uMsg, WPARAM wParam = 0L, LPARAM lParam = 0L) const;
	BOOL  PostMessage(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) const;
	BOOL  RedrawWindow(LPCRECT lpRectUpdate = NULL, CRgn* pRgn = NULL, UINT flags = RDW_INVALIDATE | RDW_UPDATENOW | RDW_ERASE | RDW_ALLCHILDREN) const;
	int   ReleaseDC(CDC* pDC) const;
	BOOL  ScreenToClient(POINT& Point) const;
	BOOL  ScreenToClient(RECT& rc) const;
	LRESULT SendDlgItemMessage(int nIDDlgItem, UINT Msg, WPARAM wParam, LPARAM lParam) const;
	LRESULT SendMessage(UINT uMsg, WPARAM wParam = 0L, LPARAM lParam = 0L) const;
	LRESULT SendMessage(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) const;
	BOOL  SendNotifyMessage(UINT Msg, WPARAM wParam, LPARAM lParam) const;
	CWnd* SetActiveWindow() const;
	CWnd* SetCapture() const;
	ULONG_PTR SetClassLongPtr(int nIndex, LONG_PTR dwNewLong) const;
	BOOL  SetDlgItemInt(int nIDDlgItem, UINT uValue, BOOL bSigned) const;
	BOOL  SetDlgItemText(int nIDDlgItem, LPCTSTR lpString) const;
	CWnd* SetFocus() const;
	void  SetFont(CFont* pFont, BOOL bRedraw = TRUE) const;
	BOOL  SetForegroundWindow() const;
	HICON SetIcon(HICON hIcon, BOOL bBigIcon) const;
	CWnd* SetParent(CWnd* pWndParent) const;
	BOOL  SetRedraw(BOOL bRedraw = TRUE) const;
	int   SetScrollInfo(int fnBar, const SCROLLINFO& si, BOOL fRedraw) const;
	UINT_PTR SetTimer(UINT_PTR nIDEvent, UINT uElapse, TIMERPROC lpTimerFunc) const;
	LONG_PTR SetWindowLongPtr(int nIndex, LONG_PTR dwNewLong) const;
	BOOL  SetWindowPos(const CWnd* pInsertAfter, int x, int y, int cx, int cy, UINT uFlags) const;
	BOOL  SetWindowPos(const CWnd* pInsertAfter, const RECT& rc, UINT uFlags) const;
	int   SetWindowRgn(CRgn* pRgn, BOOL bRedraw = TRUE) const;
	BOOL  SetWindowText(LPCTSTR lpString) const;
	HRESULT SetWindowTheme(LPCWSTR pszSubAppName, LPCWSTR pszSubIdList) const;
	BOOL  ShowWindow(int nCmdShow = SW_SHOWNORMAL) const;
	BOOL  UpdateWindow() const;
	BOOL  ValidateRect(LPCRECT prc) const;
	BOOL  ValidateRgn(CRgn* pRgn) const;
	static CWnd* WindowFromPoint(POINT pt);

#ifndef _WIN32_WCE
	BOOL  CloseWindow() const;
	int   DlgDirList(LPTSTR lpPathSpec, int nIDListBox, int nIDStaticPath, UINT uFileType) const;
	int   DlgDirListComboBox(LPTSTR lpPathSpec, int nIDComboBox, int nIDStaticPath, UINT uFiletype) const;
	BOOL  DlgDirSelectEx(LPTSTR lpString, int nCount, int nIDListBox) const;
	BOOL  DlgDirSelectComboBoxEx(LPTSTR lpString, int nCount, int nIDComboBox) const;
	BOOL  DrawAnimatedRects(int idAni, RECT& rcFrom, RECT& rcTo) const;
	BOOL  DrawCaption(CDC* pDC, RECT& rc, UINT uFlags) const;
	BOOL  EnableScrollBar(UINT uSBflags, UINT uArrows) const;
	CWnd* GetLastActivePopup() const;
	CMenu* GetMenu() const;
	int   GetScrollPos(int nBar) const;
	BOOL  GetScrollRange(int nBar, int& MinPos, int& MaxPos) const;
	CMenu* GetSystemMenu(BOOL bRevert) const;
	CWnd* GetTopWindow() const;
	BOOL  GetWindowPlacement(WINDOWPLACEMENT& pWndpl) const;
	BOOL  HiliteMenuItem(CMenu* pMenu, UINT uItemHilite, UINT uHilite) const;
	BOOL  IsIconic() const;
	BOOL  IsZoomed() const;
	BOOL  LockWindowUpdate() const;
	BOOL  OpenIcon() const;
	void  Print(CDC* pDC, DWORD dwFlags) const;
	BOOL  SetMenu(CMenu* pMenu) const;
	BOOL  ScrollWindow(int XAmount, int YAmount, LPCRECT lprcScroll, LPCRECT lprcClip) const;
	int   ScrollWindowEx(int dx, int dy, LPCRECT lprcScroll, LPCRECT lprcClip, CRgn* prgnUpdate, LPRECT lprcUpdate, UINT flags) const;
	int   SetScrollPos(int nBar, int nPos, BOOL bRedraw) const;
	BOOL  SetScrollRange(int nBar, int nMinPos, int nMaxPos, BOOL bRedraw) const;
	BOOL  SetWindowPlacement(const WINDOWPLACEMENT& wndpl) const;
	BOOL  ShowOwnedPopups(BOOL fShow) const;
	BOOL  ShowScrollBar(int nBar, BOOL bShow) const;
	BOOL  ShowWindowAsync(int nCmdShow) const;
	BOOL  UnLockWindowUpdate() const;
	CWnd* WindowFromDC(CDC* pDC) const;

#ifndef WIN32_LEAN_AND_MEAN
	void  DragAcceptFiles(BOOL fAccept) const;
#endif
#endif

	static LRESULT CALLBACK StaticWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	operator HWND() const { return m_hWnd; }

protected:
	// Override these functions as required
	virtual LRESULT FinalWindowProc(UINT uMsg, WPARAM wParam, LPARAM lParam);
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	virtual void OnCreate();
	virtual void OnDraw(CDC* pDC);
	virtual BOOL OnEraseBkgnd(CDC* pDC);
	virtual void OnInitialUpdate();
	virtual void OnMenuUpdate(UINT nID);
	virtual LRESULT OnMessageReflect(UINT uMsg, WPARAM wParam, LPARAM lParam);
	virtual LRESULT OnNotify(WPARAM wParam, LPARAM lParam);
	virtual LRESULT OnNotifyReflect(WPARAM wParam, LPARAM lParam);
	virtual void PreCreate(CREATESTRUCT& cs);
	virtual void PreRegisterClass(WNDCLASS& wc);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual LRESULT WndProc(UINT uMsg, WPARAM wParam, LPARAM lParam);
	virtual LRESULT WndProcDefault(UINT uMsg, WPARAM wParam, LPARAM lParam);

	HWND m_hWnd;					// handle to this object's window

private:
	CWnd(const CWnd&);				// Disable copy construction
	CWnd& operator = (const CWnd&); // Disable assignment operator
	void AddToMap();
	void Cleanup();
	LRESULT MessageReflect(HWND hwndParent, UINT uMsg, WPARAM wParam, LPARAM lParam);
	BOOL RegisterClass(WNDCLASS& wc);
	BOOL RemoveFromMap();
	void Subclass(HWND hWnd);

	Shared_Ptr<WNDCLASS> m_pwc;		// defines initialisation parameters for PreRegisterClass
	Shared_Ptr<CREATESTRUCT> m_pcs;	// defines initialisation parameters for PreCreate and Create
	WNDPROC m_PrevWindowProc;		// pre-subclassed Window Procedure
	BOOL m_IsTmpWnd;				// True if this CWnd is a TmpWnd

}; // class CWnd

// Special CWnd objects used by SetWindowPos
static const CWnd wndTop(HWND_TOP);
static const CWnd wndTopMost(HWND_TOPMOST);
static const CWnd wndBottom(HWND_BOTTOM);
static const CWnd wndNoTopMost(HWND_NOTOPMOST);
