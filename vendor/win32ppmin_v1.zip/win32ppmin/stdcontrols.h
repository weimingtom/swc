#pragma once

//#include "wincore.h"

	class CButton : public CWnd
	{
	public:
		CButton() {}
		virtual ~CButton() {}

		// Attributes
		HBITMAP GetBitmap() const;
		UINT GetButtonStyle() const;
		int GetCheck() const;
		HCURSOR GetCursor() const;
		HICON GetIcon() const;
		UINT GetState() const;
		HBITMAP SetBitmap(HBITMAP hBitmap) const;
		void SetButtonStyle(DWORD dwStyle, BOOL bRedraw) const;
		void SetCheck(int nCheckState) const;
		HCURSOR SetCursor(HCURSOR hCursor) const;
		HICON SetIcon(HICON hIcon) const;
		void SetState(BOOL bHighlight) const;

	protected:
		// Overridables
		virtual void PreCreate(CREATESTRUCT& cs);
	};

	class CEdit : public CWnd
	{
	public:
		// Construction
		CEdit() {}
		virtual ~CEdit() {}

		// Attributes
		BOOL CanUndo() const;
		int CharFromPos(CPoint pt) const;
		int GetFirstVisibleLine() const;
		HLOCAL GetHandle() const;
		UINT GetLimitText() const;
		int GetLine(int nIndex, LPTSTR lpszBuffer) const;
		int GetLine(int nIndex, LPTSTR lpszBuffer, int nMaxLength) const;
		int GetLineCount() const;
		DWORD GetMargins() const;
		BOOL GetModify() const;
		TCHAR GetPasswordChar() const;
		void GetRect(LPRECT lpRect) const;
		void GetSel(int& nStartChar, int& nEndChar) const;
		DWORD GetSel() const;
		CPoint PosFromChar(UINT nChar) const;
		void SetHandle(HLOCAL hBuffer) const;
		void SetLimitText(UINT nMax) const;
		void SetMargins(UINT nLeft, UINT nRight) const;
		void SetModify(BOOL bModified = TRUE) const;

		// Operations
		void EmptyUndoBuffer() const;
		BOOL FmtLines(BOOL bAddEOL) const;
		void LimitText(int nChars = 0) const;
		int LineFromChar(int nIndex = -1) const;
		int LineIndex(int nLine = -1) const;
		int LineLength(int nLine = -1) const;
		void LineScroll(int nLines, int nChars = 0) const;
		void ReplaceSel(LPCTSTR lpszNewText, BOOL bCanUndo) const;
		void SetPasswordChar(TCHAR ch) const;
		BOOL SetReadOnly(BOOL bReadOnly = TRUE) const;
		void SetRect(LPCRECT lpRect) const;
		void SetRectNP(LPCRECT lpRect) const;
		void SetSel(DWORD dwSelection, BOOL bNoScroll) const;
		void SetSel(int nStartChar, int nEndChar, BOOL bNoScroll) const;
		BOOL SetTabStops(int nTabStops, LPINT rgTabStops) const;
		BOOL SetTabStops() const;
		BOOL SetTabStops(const int& cxEachStop) const;

		//Clipboard Operations
		void Clear() const;
		void Copy() const;
		void Cut() const;
		void Paste() const;
		void Undo() const;

	protected:
		// Overridables
		virtual void PreRegisterClass(WNDCLASS &wc);
	};

	class CListBox : public CWnd
	{
	public:
		CListBox() {}
		virtual ~CListBox() {}

		// General Operations
		int  GetCount() const;
		int  GetHorizontalExtent() const;
		DWORD GetItemData(int nIndex) const;
		void* GetItemDataPtr(int nIndex) const;
		int  GetItemHeight(int nIndex) const;
		int  GetItemRect(int nIndex, LPRECT lpRect) const;
		LCID GetLocale() const;
		int  GetSel(int nIndex) const;
		int  GetText(int nIndex, LPTSTR lpszBuffer) const;
		int  GetTextLen(int nIndex) const;
		int  GetTopIndex() const;
		UINT ItemFromPoint(CPoint pt, BOOL& bOutside ) const;
		void SetColumnWidth(int cxWidth) const;
		void SetHorizontalExtent(int cxExtent) const;
		int  SetItemData(int nIndex, DWORD dwItemData) const;
		int  SetItemDataPtr(int nIndex, void* pData) const;
		int  SetItemHeight(int nIndex, UINT cyItemHeight) const;
		LCID SetLocale(LCID nNewLocale) const;
		BOOL SetTabStops(int nTabStops, LPINT rgTabStops) const;
		void SetTabStops() const;
		BOOL SetTabStops(const int& cxEachStop) const;
		int  SetTopIndex(int nIndex) const;

		// Single-Selection Operations
		int  GetCurSel() const;
		int  SetCurSel(int nSelect) const;

		// Multiple-Selection Operations
		int  GetAnchorIndex() const;
		int  GetCaretIndex() const;
		int  GetSelCount() const;
		int  GetSelItems(int nMaxItems, LPINT rgIndex) const;
		int  SelItemRange(BOOL bSelect, int nFirstItem, int nLastItem) const;
		void SetAnchorIndex(int nIndex) const;
		int  SetCaretIndex(int nIndex, BOOL bScroll) const;
		int  SetSel(int nIndex, BOOL bSelect) const;

		// String Operations
		int  AddString(LPCTSTR lpszItem) const;
		int  DeleteString(UINT nIndex) const;
		int  Dir(UINT attr, LPCTSTR lpszWildCard) const;
		int  FindString(int nStartAfter, LPCTSTR lpszItem) const;
		int  FindStringExact(int nIndexStart, LPCTSTR lpszFind) const;
		int  InsertString(int nIndex, LPCTSTR lpszItem) const;
		void ResetContent() const;
		int  SelectString(int nStartAfter, LPCTSTR lpszItem) const;

	protected:
		// Overridables
		virtual void PreRegisterClass(WNDCLASS &wc);
	};

	class CStatic : public CWnd
	{
	public:
		CStatic() {}
		virtual ~CStatic() {}

		// Operations
		HBITMAP  GetBitmap() const;
		HCURSOR GetCursor() const;
		HENHMETAFILE GetEnhMetaFile() const;
		HICON  GetIcon() const;
		HBITMAP SetBitmap(HBITMAP hBitmap) const;
		HCURSOR SetCursor(HCURSOR hCursor) const;
		HENHMETAFILE SetEnhMetaFile(HENHMETAFILE hMetaFile) const;
		HICON SetIcon(HICON hIcon) const;

	protected:
		// Overridables
		virtual void PreRegisterClass(WNDCLASS &wc);

	};
