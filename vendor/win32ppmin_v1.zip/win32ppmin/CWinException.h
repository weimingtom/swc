#pragma once

#include "wincore_head.h"

class CWinException : public std::exception
{
public:
	CWinException(LPCTSTR pszText) throw ();
	~CWinException() throw() {}
	DWORD GetError() const throw ();
	LPCTSTR GetErrorString() const throw ();
	const char * what () const throw ();

private:
	DWORD  m_Error;
	LPCTSTR m_pszText;
	TCHAR m_szErrorString[MAX_STRING_SIZE];
};
