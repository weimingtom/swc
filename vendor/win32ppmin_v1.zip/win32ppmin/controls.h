#pragma once

//#include "wincore.h"
#include "stdcontrols.h"

	// Forward declarations
	class CMonthCalendar;
	class CToolTip;

	class CAnimation : public CWnd
	{
	public:
		CAnimation() {}
		virtual ~CAnimation() {}

		BOOL Close() const;
		BOOL Open(LPTSTR lpszName) const;
		BOOL Play(UINT wFrom, UINT wTo, UINT cRepeat) const;
		BOOL Seek(UINT wFrame) const;
		BOOL Stop() const;

	protected:
		// Overridables
		virtual void PreRegisterClass(WNDCLASS &wc) { wc.lpszClassName = ANIMATE_CLASS; }
	};


	class CComboBox : public CWnd
	{
	public:
		CComboBox() {}
		virtual ~CComboBox() { ::InitCommonControls(); }

		int   AddString(LPCTSTR lpszString) const;
		void  Clear() const;
		void  Copy() const;
		void  Cut() const;
		int   DeleteString(int nIndex) const;
		int   Dir(UINT attr, LPCTSTR lpszWildCard ) const;
		int   FindString(int nIndexStart, LPCTSTR lpszString) const;
		int   FindStringExact(int nIndexStart, LPCTSTR lpszString) const;
		int   GetCount() const;
		int   GetCurSel() const;
		CRect GetDroppedControlRect() const;
		BOOL  GetDroppedState() const;
		int   GetDroppedWidth() const;
		DWORD GetEditSel() const;
		BOOL  GetExtendedUI() const;
		int   GetHorizontalExtent() const;
		DWORD GetItemData(int nIndex) const;
		int   GetItemHeight(int nIndex) const;
		int   GetLBText(int nIndex, LPTSTR lpszText) const;
		int   GetLBTextLen(int nIndex) const;
		LCID  GetLocale() const;
		int   GetTopIndex() const;
		int   InitStorage(int nItems, int nBytes) const;
		int   InsertString(int nIndex, LPCTSTR lpszString) const;
		void  LimitText(int nMaxChars) const;
		void  Paste() const;
		void  ResetContent() const;
		int   SelectString(int nStartAfter, LPCTSTR lpszString) const;
		int   SetCurSel(int nIndex) const;
		int   SetDroppedWidth(int nWidth) const;
		BOOL  SetEditSel(int nStartChar, int nEndChar) const;
		int   SetExtendedUI(BOOL bExtended = TRUE) const;
		void  SetHorizontalExtent(UINT nExtent ) const;
		int   SetItemData(int nIndex, DWORD dwItemData) const;
		int   SetItemHeight(int nIndex, UINT cyItemHeight) const;
		LCID  SetLocale( LCID NewLocale ) const;
		int   SetTopIndex(int nIndex) const;
		void  ShowDropDown(BOOL bShow = TRUE) const;

	protected:
		// Overridables
		virtual void PreRegisterClass(WNDCLASS &wc) { wc.lpszClassName = _T("ComboBox"); }
	};


	class CComboBoxEx : public CComboBox
	{
	public:
		CComboBoxEx() 
		{
			INITCOMMONCONTROLSEX icce;
			icce.dwSize = sizeof(INITCOMMONCONTROLSEX);
			icce.dwICC = ICC_USEREX_CLASSES;
			::InitCommonControlsEx(&icce);		
		}
		virtual ~CComboBoxEx() {}

		int  	DeleteItem(int nIndex ) const;
		CWnd* 	GetComboBoxCtrl() const;
		CEdit* 	GetEditCtrl() const;
		DWORD 	GetExtendedStyle() const;
		HIMAGELIST GetImageList() const;
		BOOL 	GetItem(COMBOBOXEXITEM* pCBItem) const;
		BOOL 	HasEditChanged () const;
		int     InsertItem(COMBOBOXEXITEM* lpcCBItem) const;
		DWORD 	SetExtendedStyle(DWORD dwExMask, DWORD dwExStyles ) const;
		HIMAGELIST SetImageList(HIMAGELIST himl) const;
		BOOL 	SetItem(PCOMBOBOXEXITEM lpcCBItem) const;

	protected:
		// Overridables
		virtual void PreRegisterClass(WNDCLASS &wc) { wc.lpszClassName = WC_COMBOBOXEX; }
	};


	class CDateTime : public CWnd
	{
	public:
		CDateTime()
		{
			INITCOMMONCONTROLSEX icce;
			icce.dwSize = sizeof(INITCOMMONCONTROLSEX);
			icce.dwICC = ICC_DATE_CLASSES;
			::InitCommonControlsEx(&icce);
		}
		virtual ~CDateTime() {}

		COLORREF GetMonthCalColor(int iColor) const;
		COLORREF SetMonthCalColor(int iColor, COLORREF ref);
		BOOL SetFormat(LPCTSTR pstrFormat);
		CMonthCalendar* GetMonthCalCtrl() const;
		CFont* GetMonthCalFont() const;
		void SetMonthCalFont(HFONT hFont, BOOL bRedraw = TRUE);
		DWORD GetRange(LPSYSTEMTIME lpSysTimeArray) const;
		BOOL SetRange(DWORD flags, LPSYSTEMTIME lpSysTimeArray);
		DWORD GetTime(LPSYSTEMTIME pTimeDest) const;
		BOOL SetTime(DWORD flag, LPSYSTEMTIME pTimeNew = NULL);

	protected:
		// Overridables
		virtual void PreRegisterClass(WNDCLASS &wc) { wc.lpszClassName = DATETIMEPICK_CLASS; }
	};

	class CHeader : public CWnd
	{
	public:
		CHeader()
		{
			INITCOMMONCONTROLSEX icex;
			icex.dwSize = sizeof(INITCOMMONCONTROLSEX);
			icex.dwICC = ICC_WIN95_CLASSES;
			::InitCommonControlsEx(&icex);
		}
		virtual ~CHeader() {}

		// Attributes
		HIMAGELIST GetImageList() const;
		BOOL GetItem(int nPos, HDITEM* pHeaderItem) const;
		int GetItemCount() const;
		CRect GetItemRect(int nIndex) const;
		BOOL GetOrderArray(LPINT piArray, int iCount);
		int OrderToIndex(int nOrder) const;
		HIMAGELIST SetImageList(HIMAGELIST himl);
		BOOL SetItem(int nPos, HDITEM* pHeaderItem);
		BOOL SetOrderArray(int iCount, LPINT piArray);
		int GetBitmapMargin() const;
		int SetBitmapMargin(int nWidth);

		// Operations
		HIMAGELIST CreateDragImage(int nIndex);
		BOOL DeleteItem(int nPos);
		int InsertItem(int nPos, HDITEM* phdi);
		BOOL Layout(HDLAYOUT* pHeaderLayout);
#ifdef Header_SetHotDivider
		int SetHotDivider(CPoint pt);
		int SetHotDivider(int nIndex);
#endif
#ifdef Header_ClearFilter
		int ClearAllFilters();
		int ClearFilter(int nColumn);
		int EditFilter(int nColumn, BOOL bDiscardChanges);
		int SetFilterChangeTimeout(DWORD dwTimeOut);
#endif

	protected:
		// Overridables
		virtual void PreRegisterClass(WNDCLASS &wc) { wc.lpszClassName = WC_HEADER ; }
	};

	class CHotKey : public CWnd
	{
	public:
		CHotKey() { ::InitCommonControls(); }
		virtual ~CHotKey() {}

		DWORD GetHotKey() const;
		CString GetKeyName(UINT vk, BOOL fExtended) const;
		void SetHotKey(DWORD dwKey);
		void SetRules(WORD wInvalidComb, WORD wModifiers);

	protected:
		// Overridables
		virtual void PreRegisterClass(WNDCLASS &wc) { wc.lpszClassName = HOTKEY_CLASS; }
	};

	class CIPAddress : public CWnd
	{
	public:
		CIPAddress()
		{
			INITCOMMONCONTROLSEX icex;
			icex.dwSize = sizeof(INITCOMMONCONTROLSEX);
			icex.dwICC = ICC_INTERNET_CLASSES;
			::InitCommonControlsEx(&icex);
		}
		virtual ~CIPAddress() {}

		void ClearAddress();
		int GetAddress(BYTE& nField0, BYTE& nField1, BYTE& nField2, BYTE& nField3);
		int GetAddress(DWORD* dwAddress);
		BOOL IsBlank() const;
		void SetAddress(BYTE nField0, BYTE nField1, BYTE nField2, BYTE nField3);
		void SetAddress(DWORD dwAddress);
		void SetFieldFocus(WORD nField);
		void SetFieldRange(int nField, BYTE nLower, BYTE nUpper);

	protected:
		// Overridables
		virtual void PreRegisterClass(WNDCLASS &wc) { wc.lpszClassName = WC_IPADDRESS; }

	};

	class CMonthCalendar : public CWnd
	{
	public:
		CMonthCalendar()
		{
			INITCOMMONCONTROLSEX icex;
			icex.dwSize = sizeof(icex);
			icex.dwICC  = ICC_DATE_CLASSES;
			InitCommonControlsEx(&icex);
		}
		virtual ~CMonthCalendar() {}

		// Attributes
		COLORREF GetColor(int nRegion) const;
		int GetFirstDayOfWeek(BOOL* pbLocal = NULL) const;
		CRect GetMinReqRect() const;
		int GetMonthDelta() const;
		COLORREF SetColor(int nRegion, COLORREF ref);
		BOOL SetFirstDayOfWeek(int iDay, int* lpnOld = NULL);
		int SetMonthDelta(int iDelta);

		// Operations
		BOOL GetCurSel(LPSYSTEMTIME pDateTime) const;
		int GetMaxSelCount() const;
		int GetMonthRange(LPSYSTEMTIME pMinRange, LPSYSTEMTIME pMaxRange, DWORD dwFlags) const;
		DWORD GetRange(LPSYSTEMTIME pMinRange, LPSYSTEMTIME pMaxRange) const;
		BOOL GetSelRange(LPSYSTEMTIME pMinRange, LPSYSTEMTIME pMaxRange) const;
		BOOL GetToday(LPSYSTEMTIME pDateTime) const;
		DWORD HitTest(PMCHITTESTINFO pMCHitTest);
		BOOL SetCurSel(const LPSYSTEMTIME pDateTime);
		BOOL SetDayState(int nMonths, LPMONTHDAYSTATE pStates);
		BOOL SetMaxSelCount(int nMax);
		BOOL SetRange(const LPSYSTEMTIME pMinRange, const LPSYSTEMTIME pMaxRange);
		BOOL SetSelRange(const LPSYSTEMTIME pMinRange, const LPSYSTEMTIME pMaxRange);
		void SetToday(const LPSYSTEMTIME pDateTime);

	protected:
		// Overridables
		virtual void PreRegisterClass(WNDCLASS &wc) { wc.lpszClassName = MONTHCAL_CLASS; }
	};

	class CProgressBar : public CWnd
	{
	public:
		CProgressBar() { ::InitCommonControls(); }
		virtual ~CProgressBar() {}

		int  GetPos() const;
		int  GetRange(BOOL fWhichLimit, PPBRANGE ppBRange) const;
		int  OffsetPos(int nIncrement) const;
		int  SetPos(int nNewPos) const;
		int  SetRange(short nMinRange, short nMaxRange) const;
		int  SetStep(int nStepInc) const;
		int  StepIt() const;

	protected:
		// Overridables
		virtual void PreRegisterClass(WNDCLASS &wc) { wc.lpszClassName = PROGRESS_CLASS; }
	};

	class CScrollBar : public CWnd
	{
	public:
		CScrollBar() {}
		virtual ~CScrollBar() {}

		BOOL EnableScrollBar( UINT nArrowFlags = ESB_ENABLE_BOTH )  const;
		BOOL GetScrollInfo(LPSCROLLINFO lpsi)  const;
		int  GetScrollPos()  const;
		BOOL GetScrollRange(LPINT lpMinPos, LPINT lpMaxPos )  const;
		BOOL SetScrollInfo(LPSCROLLINFO lpsi, BOOL bRedraw = TRUE )  const;
		int  SetScrollPos(int nPos, BOOL bRedraw)  const;
		BOOL SetScrollRange( int nMinPos, int nMaxPos, BOOL bRedraw = TRUE )  const;
		BOOL ShowScrollBar(BOOL bShow)  const;

	protected:
		// Overridables
		virtual void PreRegisterClass(WNDCLASS &wc) { wc.lpszClassName = _T("SCROLLBAR"); ; }
	};

	class CSlider : public CWnd
	{
	public:
		CSlider() { ::InitCommonControls(); }
		virtual ~CSlider() {}

		void ClearSel() const;
		void ClearTics(BOOL bRedraw = FALSE ) const;
		CWnd* GetBuddy(BOOL fLocation = TRUE ) const;
		CRect GetChannelRect() const;
		int  GetLineSize() const;
		int  GetNumTics() const;
		int  GetPageSize() const;
		int  GetPos() const;
		int  GetRangeMax() const;
		int  GetRangeMin() const;
		int  GetSelEnd() const;
		int  GetSelStart() const;
		int  GetThumbLength() const;
		CRect GetThumbRect() const;
		int  GetTic(int nTic ) const;
		int  GetTicPos(int nTic) const;
		CToolTip* GetToolTips() const;
		CWnd* SetBuddy(CWnd* pBuddy, BOOL fLocation = TRUE ) const;
		int  SetLineSize(int nSize) const;
		int  SetPageSize(int nSize) const;
		void SetPos(int nPos, BOOL bRedraw = FALSE) const;
		void SetRangeMax(int nMax, BOOL bRedraw = FALSE) const;
		void SetRangeMin(int nMax, BOOL bRedraw = FALSE) const;
		void SetSelection(int nMin, int nMax, BOOL bRedraw = FALSE) const;
		BOOL SetTic(int nTic) const;
		void SetTicFreq(int nFreq)  const;
		int  SetTipSide(int nLocation) const;
		void SetToolTips(CToolTip* pToolTip) const;

	protected:
		// Overridables
		virtual void PreRegisterClass(WNDCLASS &wc) { wc.lpszClassName = TRACKBAR_CLASS; }
	};


	// Also known as an Up/Down control
	class CSpinButton : public CWnd
	{
	public:
		CSpinButton() { ::InitCommonControls(); }
		virtual ~CSpinButton() {}

		int  GetAccel(int cAccels, LPUDACCEL paAccels) const;
		int  GetBase() const;
		CWnd* GetBuddy() const;
		int  GetPos() const;
		DWORD GetRange() const;
		BOOL SetAccel(int cAccels, LPUDACCEL paAccels) const;
		int  SetBase(int nBase) const;
		CWnd* SetBuddy(CWnd* hwndBuddy) const;
		int  SetPos(int nPos) const;
		void SetRange(int nLower, int nUpper) const;

	protected:
		// Overridables
		virtual void PreCreate(CREATESTRUCT &cs);
		virtual void PreRegisterClass(WNDCLASS &wc);
	};

	class CToolTip : public CWnd
	{
	public:
		CToolTip();
		virtual ~CToolTip();

		//Attributes
		int GetDelayTime(DWORD dwDuration) const;
		void GetMargin(LPRECT lprc) const;
		int GetMaxTipWidth() const;
		void GetText(CString& str, CWnd* pWnd, UINT_PTR nIDTool = 0) const;
		COLORREF GetTipBkColor() const;
		COLORREF GetTipTextColor() const;
		int GetToolCount() const;
		BOOL GetToolInfo(TOOLINFO& ToolInfo, CWnd* pWnd, UINT_PTR nIDTool = 0) const;
		void SetDelayTime(UINT nDelay);
		void SetDelayTime(DWORD dwDuration, int iTime);
		void SetMargin(LPRECT lprc);
		int SetMaxTipWidth(int iWidth);
		void SetTipBkColor(COLORREF clr);
		void SetTipTextColor(COLORREF clr);
		void SetToolInfo(LPTOOLINFO lpToolInfo);
#if (defined TTM_SETTITLE) && (_WIN32_IE >=0x0500)
		CSize GetBubbleSize(LPTOOLINFO lpToolInfo) const;
#endif

		//Operations
		void Activate(BOOL bActivate);
		BOOL AddTool(CWnd* pWnd, UINT nIDText, LPCRECT lpRectTool = NULL, UINT_PTR nIDTool = 0);
		BOOL AddTool(CWnd* pWnd, LPCTSTR lpszText = LPSTR_TEXTCALLBACK, LPCRECT lpRectTool = NULL, UINT_PTR nIDTool = 0);
		void DelTool(CWnd* pWnd, UINT_PTR nIDTool = 0);
		BOOL HitTest(CWnd* pWnd, CPoint pt, LPTOOLINFO lpToolInfo) const;
		void Pop();
		void RelayEvent(LPMSG lpMsg);

		void SetToolRect(CWnd* pWnd, UINT_PTR nIDTool, LPCRECT lpRect);
		void Update();
		void UpdateTipText(LPCTSTR lpszText, CWnd* pWnd, UINT_PTR nIDTool = 0);
		void UpdateTipText(UINT nIDText, CWnd* pWnd, UINT_PTR nIDTool = 0);

#if (defined TTM_SETTITLE) && (_WIN32_IE >=0x0500)
		BOOL AdjustRect(LPRECT lprc, BOOL bLarger = TRUE);
		BOOL SetTitle(UINT uIcon, LPCTSTR lpstrTitle);
#endif
#if (defined TTM_SETWINDOWTHEME) && (WINVER >= 0x0501)
		HRESULT SetWindowTheme(LPCWSTR lpstrTheme);
#endif

	protected:
		// Overridables
		virtual void PreRegisterClass(WNDCLASS &wc) { wc.lpszClassName = TOOLTIPS_CLASS; ; }
		virtual void PreCreate(CREATESTRUCT &cs) 
		{ 
			cs.dwExStyle = WS_EX_TOOLWINDOW; 
			cs.style = WS_POPUP | TTS_NOPREFIX | TTS_ALWAYSTIP;
		}

	private:
		void LoadToolInfo(TOOLINFO& ti, CWnd* pWnd, UINT_PTR nIDTool) const;
	};



