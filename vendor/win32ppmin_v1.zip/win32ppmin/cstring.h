#pragma once

//#include "wincore.h"
#include "wincore_head.h"

class CString
{
	// friend functions allow the left hand side to be something other than CString
	friend CString operator + (const CString& string1, const CString& string2);
	friend CString operator + (const CString& string, LPCTSTR pszText);
	friend CString operator + (const CString& string, TCHAR ch);
	friend CString operator + (LPCTSTR pszText, const CString& string);
	friend CString operator + (TCHAR ch, const CString& string);
	friend bool    operator < (const CString& string1, const CString& string2);
	friend bool    operator > (const CString& string1, const CString& string2);
	friend bool    operator < (const CString& string1, LPCTSTR pszText);
	friend bool    operator > (const CString& string1, LPCTSTR pszText);
	friend bool    operator <= (const CString& string1, const CString& string2);
	friend bool    operator >= (const CString& string1, const CString& string2);
	friend bool    operator <= (const CString& string1, LPCTSTR pszText);
	friend bool    operator >= (const CString& string1, LPCTSTR pszText);

public:
	CString();
	~CString();
	CString(const CString& str);
	CString(LPCSTR pszText);
	CString(LPCWSTR pszText);
	CString(TCHAR ch, int nLength = 1);
	CString(LPCTSTR pszText, int nLength);

	CString& operator = (const CString& str);
	CString& operator = (const TCHAR ch);
	CString& operator = (LPCSTR pszText);
	CString& operator = (LPCWSTR pszText);
	bool     operator == (LPCTSTR pszText);
	bool     operator != (LPCTSTR pszText);
			 operator LPCTSTR() const;
	TCHAR&   operator [] (int nIndex);
	CString& operator += (const CString& str);
	CString& operator += (LPCSTR szText);
	CString& operator += (LPCWSTR szText);

	// Attributes
	LPCTSTR	 c_str() const		{ return m_str.c_str(); }		// alternative for casting to LPCTSTR
	tString& GetString()		{ return m_str; }				// returns a reference to the underlying std::basic_string<TCHAR>
	int      GetLength() const	{ return (int)m_str.length(); }	// returns the length in characters

	// Operations
	BSTR     AllocSysString() const;
	void	 AppendFormat(LPCTSTR pszFormat,...);
	void	 AppendFormat(UINT nFormatID, ...);
	int      Compare(LPCTSTR pszText) const;
	int      CompareNoCase(LPCTSTR pszText) const;
	int      Delete(int nIndex, int nCount = 1);
	int		 Find(TCHAR ch, int nIndex = 0 ) const;
	int      Find(LPCTSTR pszText, int nStart = 0) const;
	int		 FindOneOf(LPCTSTR pszText) const;
	void	 Format(UINT nID, ...);
	void     Format(LPCTSTR pszFormat,...);
	void     FormatV(LPCTSTR pszFormat, va_list args);
	void	 FormatMessage(LPCTSTR pszFormat,...);
	void	 FormatMessageV(LPCTSTR pszFormat, va_list args);
	TCHAR	 GetAt(int nIndex) const;
	LPTSTR	 GetBuffer(int nMinBufLength);
	void	 GetErrorString(DWORD dwError);
	void     Empty();
	int      Insert(int nIndex, TCHAR ch);
	int      Insert(int nIndex, const CString& str);
	bool     IsEmpty() const;
	CString  Left(int nCount) const;
	bool	 LoadString(UINT nID);
	void     MakeLower();
	void	 MakeReverse();
	void     MakeUpper();
	CString	 Mid(int nFirst) const;
	CString  Mid(int nFirst, int nCount) const;
	void	 ReleaseBuffer( int nNewLength = -1 );
	int      Remove(LPCTSTR pszText);
	int      Replace(TCHAR chOld, TCHAR chNew);
	int      Replace(const LPCTSTR pszOld, LPCTSTR pszNew);
	int      ReverseFind(LPCTSTR pszText, int nStart = -1) const;
	CString  Right(int nCount) const;
	void	 SetAt(int nIndex, TCHAR ch);
	BSTR	 SetSysString(BSTR* pBstr) const;
	CString	 SpanExcluding(LPCTSTR pszText) const;
	CString	 SpanIncluding(LPCTSTR pszText) const;
	CString	 Tokenize(LPCTSTR pszTokens, int& iStart) const;
	void	 Trim();
	void	 TrimLeft();
	void	 TrimLeft(TCHAR chTarget);
	void	 TrimLeft(LPCTSTR pszTargets);
	void	 TrimRight();
	void	 TrimRight(TCHAR chTarget);
	void	 TrimRight(LPCTSTR pszTargets);
	void     Truncate(int nNewLength);

#ifndef _WIN32_WCE
	int      Collate(LPCTSTR pszText) const;
	int		 CollateNoCase(LPCTSTR pszText) const;
	bool	 GetEnvironmentVariable(LPCTSTR pszVar);
#endif

private:
	tString m_str;
	std::vector<TCHAR> m_buf;
};

///////////////////////////////////
// Global Functions
//

// friend functions of CString
inline CString operator + (const CString& string1, const CString& string2)
{
	CString str(string1);
	str.m_str.append(string2.m_str);
	return str;
}

inline CString operator + (const CString& string, LPCTSTR pszText)
{
	CString str(string);
	str.m_str.append(pszText);
	return str;
}

inline CString operator + (const CString& string, TCHAR ch)
{
	CString str(string);
	str.m_str.append(1, ch);
	return str;
}

inline CString operator + (LPCTSTR pszText, const CString& string)
{
	CString str(pszText);
	str.m_str.append(string);
	return str;
}

inline CString operator + (TCHAR ch, const CString& string)
{
	CString str(ch);
	str.m_str.append(string);
	return str;
}

inline bool operator < (const CString& string1, const CString& string2)
{
	return string1.Compare(string2) < 0;
}

inline bool operator > (const CString& string1, const CString& string2)
{
	return string1.Compare(string2) > 0;
}

inline bool operator <= (const CString& string1, const CString& string2)
{
	return string1.Compare(string2) <= 0;
}

inline bool operator >= (const CString& string1, const CString& string2)
{
	return string1.Compare(string2) >= 0;
}

inline bool	operator < (const CString& string1, LPCTSTR pszText)
{
	return string1.Compare(pszText) < 0;
}

inline bool	operator > (const CString& string1, LPCTSTR pszText)
{
	return string1.Compare(pszText) > 0;
}

inline bool operator <= (const CString& string1, LPCTSTR pszText)
{
	return string1.Compare(pszText) <= 0;
}

inline bool operator >= (const CString& string1, LPCTSTR pszText)
{
	return string1.Compare(pszText) >= 0;
}

// Global LoadString
inline CString LoadString(UINT nID)
{
	CString str;
	str.LoadString(nID);
	return str;
}
