#pragma once

//#include "wincore.h"
#include "gdi.h"
#include "controls.h"

struct ReBarTheme
{
	BOOL UseThemes;			// TRUE if themes are used
	COLORREF clrBkgnd1;		// Colour 1 for rebar background
	COLORREF clrBkgnd2;		// Colour 2 for rebar background
	COLORREF clrBand1;		// Colour 1 for rebar band background. Use NULL if not required
	COLORREF clrBand2;		// Colour 2 for rebar band background. Use NULL if not required
	BOOL FlatStyle;			// Bands are rendered with flat rather than raised style
	BOOL BandsLeft;			// Position bands left on rearrange
	BOOL LockMenuBand;		// Lock MenuBar's band in dedicated top row, without gripper
	BOOL RoundBorders;		// Use rounded band borders
	BOOL ShortBands;        // Allows bands to be shorter than maximum available width
	BOOL UseLines;			// Displays horizontal lines between bands
};

////////////////////////////////////
// Declaration of the CReBar class
//
class CReBar : public CWnd
{
public:
	CReBar();
	virtual ~CReBar();

	// Operations
	BOOL DeleteBand(const int nBand) const;
	int  HitTest(RBHITTESTINFO& rbht);
	HWND HitTest(POINT pt);
	int  IDToIndex(UINT uBandID) const;
	BOOL InsertBand(const int nBand, REBARBANDINFO& rbbi) const;
	BOOL IsBandVisible(int nBand) const;
	void MaximizeBand(UINT uBand, BOOL fIdeal = FALSE);
	void MinimizeBand(UINT uBand);
	BOOL MoveBand(UINT uFrom, UINT uTo);
	void MoveBandsLeft();
	BOOL ResizeBand(const int nBand, const CSize& sz) const;
	BOOL ShowGripper(int nBand, BOOL fShow) const;
	BOOL ShowBand(int nBand, BOOL fShow) const;
	BOOL SizeToRect(CRect& rect) const;
	
	// Attributes
	int  GetBand(const HWND hWnd) const;
	CRect GetBandBorders(int nBand) const;
	int  GetBandCount() const;
	BOOL GetBandInfo(const int nBand, REBARBANDINFO& rbbi) const;
	CRect GetBandRect(int i) const;
	UINT GetBarHeight() const;
	BOOL GetBarInfo(REBARINFO& rbi) const;
	HWND GetMenuBar() {return m_hMenuBar;}
	ReBarTheme& GetReBarTheme() {return m_Theme;}
	UINT GetRowCount() const;
	int  GetRowHeight(int nRow) const;
	UINT GetSizeofRBBI() const;
	CToolTip* GetToolTips() const;
	BOOL SetBandBitmap(const int nBand, const CBitmap* pBackground) const;
	BOOL SetBandColor(const int nBand, const COLORREF clrFore, const COLORREF clrBack) const;
	BOOL SetBandInfo(const int nBand, REBARBANDINFO& rbbi) const;
	BOOL SetBarInfo(REBARINFO& rbi) const;
	void SetMenuBar(HWND hMenuBar) {m_hMenuBar = hMenuBar;}
	void SetReBarTheme(ReBarTheme& Theme);
	void SetToolTips(CToolTip* pToolTip) const;

protected:
//Overridables
	virtual BOOL OnEraseBkgnd(CDC* pDC);
	virtual void PreCreate(CREATESTRUCT& cs);
	virtual void PreRegisterClass(WNDCLASS &wc);
	virtual LRESULT WndProcDefault(UINT uMsg, WPARAM wParam, LPARAM lParam);

private:
	CReBar(const CReBar&);				// Disable copy construction
	CReBar& operator = (const CReBar&); // Disable assignment operator

	ReBarTheme m_Theme;
	BOOL m_bIsDragging;
	HWND m_hMenuBar;
	LPARAM m_Orig_lParam;
};
