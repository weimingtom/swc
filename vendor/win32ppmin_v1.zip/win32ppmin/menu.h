#pragma once

//#include "wincore.h"
#include "gdi.h"

class CBitmap;

class CMenu
{
	friend class CWinApp;

public:
	//Construction
	CMenu() : m_hMenu(0), m_IsTmpMenu(FALSE) {}
	CMenu(UINT nID) : m_IsTmpMenu(FALSE) 
	{
		m_hMenu = ::LoadMenu(GetApp()->GetResourceHandle(), MAKEINTRESOURCE(nID));
	}
	~CMenu();

	//Initialization
	void Attach(HMENU hMenu);
	void CreateMenu();
	void CreatePopupMenu();
	void DestroyMenu();
	HMENU Detach();
	HMENU GetHandle() const;
	BOOL LoadMenu(LPCTSTR lpszResourceName);
	BOOL LoadMenu(UINT uIDResource);
	BOOL LoadMenuIndirect(const void* lpMenuTemplate);

	//Menu Operations
	BOOL TrackPopupMenu(UINT uFlags, int x, int y, CWnd* pWnd, LPCRECT lpRect = 0);
	BOOL TrackPopupMenuEx(UINT uFlags, int x, int y, CWnd* pWnd, LPTPMPARAMS lptpm);

	//Menu Item Operations
	BOOL AppendMenu(UINT uFlags, UINT_PTR uIDNewItem = 0, LPCTSTR lpszNewItem = NULL);
	BOOL AppendMenu(UINT uFlags, UINT_PTR uIDNewItem, const CBitmap* pBmp);
	UINT CheckMenuItem(UINT uIDCheckItem, UINT uCheck);
	BOOL CheckMenuRadioItem(UINT uIDFirst, UINT uIDLast, UINT uIDItem, UINT uFlags);
	BOOL DeleteMenu(UINT uPosition, UINT uFlags);
	UINT EnableMenuItem(UINT uIDEnableItem, UINT uEnable);
	UINT GetDefaultItem(UINT gmdiFlags, BOOL fByPos = FALSE);
	DWORD GetMenuContextHelpId() const;

#if(WINVER >= 0x0500)	// Minimum OS required is Win2000
	BOOL GetMenuInfo(LPMENUINFO lpcmi) const;
	BOOL SetMenuInfo(LPCMENUINFO lpcmi);
#endif

	UINT GetMenuItemCount() const;
	UINT GetMenuItemID(int nPos) const;
	BOOL GetMenuItemInfo(UINT uItem, LPMENUITEMINFO lpMenuItemInfo, BOOL fByPos = FALSE);
	UINT GetMenuState(UINT uID, UINT uFlags) const;
	int GetMenuString(UINT uIDItem, LPTSTR lpString, int nMaxCount, UINT uFlags) const;
	int GetMenuString(UINT uIDItem, CString& rString, UINT uFlags) const;
	CMenu* GetSubMenu(int nPos);
	BOOL InsertMenu(UINT uPosition, UINT uFlags, UINT_PTR uIDNewItem = 0, LPCTSTR lpszNewItem = NULL);
	BOOL InsertMenu(UINT uPosition, UINT uFlags, UINT_PTR uIDNewItem, const CBitmap* pBmp);
	BOOL InsertMenuItem(UINT uItem, LPMENUITEMINFO lpMenuItemInfo, BOOL fByPos = FALSE);
	BOOL ModifyMenu(UINT uPosition, UINT uFlags, UINT_PTR uIDNewItem = 0, LPCTSTR lpszNewItem = NULL);
	BOOL ModifyMenu(UINT uPosition, UINT uFlags, UINT_PTR uIDNewItem, const CBitmap* pBmp);
	BOOL RemoveMenu(UINT uPosition, UINT uFlags);
	BOOL SetDefaultItem(UINT uItem, BOOL fByPos = FALSE);
	BOOL SetMenuContextHelpId(DWORD dwContextHelpId);
	BOOL SetMenuItemBitmaps(UINT uPosition, UINT uFlags, const CBitmap* pBmpUnchecked, const CBitmap* pBmpChecked);
	BOOL SetMenuItemInfo(UINT uItem, LPMENUITEMINFO lpMenuItemInfo, BOOL fByPos = FALSE);

	//Operators
	BOOL operator != (const CMenu& menu) const;
	BOOL operator == (const CMenu& menu) const;
	operator HMENU () const;

private:
	CMenu(const CMenu&);				// Disable copy construction
	CMenu& operator = (const CMenu&);	// Disable assignment operator
	void AddToMap();
	BOOL RemoveFromMap();
	std::vector<MenuPtr> m_vSubMenus;	// A vector of smart pointers to CMenu
	HMENU m_hMenu;
	BOOL m_IsTmpMenu;
};

///////////////////////////////////////
// Global functions
//

inline CMenu* FromHandle(HMENU hMenu)
// Returns the CMenu object associated with the menu handle (HMENU).
{
	assert( GetApp() );
	CMenu* pMenu = GetApp()->GetCMenuFromMap(hMenu);
	if (::IsMenu(hMenu) && pMenu == 0)
	{
		GetApp()->AddTmpMenu(hMenu);
		pMenu = GetApp()->GetCMenuFromMap(hMenu);
	}
	return pMenu;
}
