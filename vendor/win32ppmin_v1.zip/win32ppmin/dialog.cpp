#include "dialog.h"
#include "CWinApp.h"
#include "gdi.h"
#include "CWinException.h"
#include "menu.h"
#include "winutils.h"

CDialog::CDialog(LPCTSTR lpszResName, CWnd* pParent/* = NULL*/)
	: m_IsModal(TRUE), m_lpszResName(lpszResName), m_lpTemplate(NULL)
{
	m_hParent = pParent? pParent->GetHwnd() : NULL;
	::InitCommonControls();
}

CDialog::CDialog(UINT nResID, CWnd* pParent/* = NULL*/)
	: m_IsModal(TRUE), m_lpszResName(MAKEINTRESOURCE (nResID)), m_lpTemplate(NULL)
{
	m_hParent = pParent? pParent->GetHwnd() : NULL;
	::InitCommonControls();
}

//For indirect dialogs - created from a dialog box template in memory.
CDialog::CDialog(LPCDLGTEMPLATE lpTemplate, CWnd* pParent/* = NULL*/)
	: m_IsModal(TRUE), m_lpszResName(NULL), m_lpTemplate(lpTemplate)
{
	m_hParent = pParent? pParent->GetHwnd() : NULL;
	::InitCommonControls();
}

CDialog::~CDialog()
{
	if (m_hWnd != NULL)
	{
		if (IsModal())
			::EndDialog(m_hWnd, 0);
		else
			Destroy();
	}
}

void CDialog::AttachItem(int nID, CWnd& Wnd)
// Attach a dialog item to a CWnd
{
	Wnd.AttachDlgItem(nID, this);
}

HWND CDialog::Create(CWnd* pParent /* = NULL */)
{
	// Allow a dialog to be used as a child window

	assert(GetApp());
	SetDlgParent(pParent);
	return DoModeless();
}

INT_PTR CDialog::DialogProc(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	// Override this function in your class derrived from CDialog if you wish to handle messages
	// A typical function might look like this:

	//	switch (uMsg)
	//	{
	//	case MESSAGE1:		// Some Windows API message
	//		OnMessage1();	// A user defined function
	//		break;			// Also do default processing
	//	case MESSAGE2:
	//		OnMessage2();
	//		return x;		// Don't do default processing, but instead return
	//						//  a value recommended by the Windows API documentation
	//	}

	// Always pass unhandled messages on to DialogProcDefault
	return DialogProcDefault(uMsg, wParam, lParam);
}

INT_PTR CDialog::DialogProcDefault(UINT uMsg, WPARAM wParam, LPARAM lParam)
// All DialogProc functions should pass unhandled messages to this function
{
	LRESULT lr = 0;

	switch (uMsg)
	{
		case WM_TIMER:
			if (wParam == IDLE_TIMER_ID)
				GetApp()->CleanupTemps();
		return 0L;
	case UWM_CLEANUPTEMPS:
		{
			TLSData* pTLSData = (TLSData*)TlsGetValue(GetApp()->GetTlsIndex());
			pTLSData->vTmpWnds.clear();
		}
		break;
	case WM_INITDIALOG:
		{
			// Center the dialog
			CenterWindow();
			if (IsModal())
				SetTimer(IDLE_TIMER_ID, 1000, 0);
		}
		return OnInitDialog();
	case WM_COMMAND:
		switch (LOWORD (wParam))
		{
		case IDOK:
			OnOK();
			return TRUE;
		case IDCANCEL:
			OnCancel();
			return TRUE;
		default:
			{
				// Refelect this message if it's from a control
				CWnd* pWnd = GetApp()->GetCWndFromMap((HWND)lParam);
				if (pWnd != NULL)
					lr = pWnd->OnCommand(wParam, lParam);

				// Handle user commands
				if (!lr)
					lr =  OnCommand(wParam, lParam);

				if (lr) return 0L;
			}
			break;  // Some commands require default processing
		}
		break;

	case WM_NOTIFY:
		{
			// Do Notification reflection if it came from a CWnd object
			HWND hwndFrom = ((LPNMHDR)lParam)->hwndFrom;
			CWnd* pWndFrom = GetApp()->GetCWndFromMap(hwndFrom);

			if (pWndFrom != NULL)
				lr = pWndFrom->OnNotifyReflect(wParam, lParam);
			else
			{
				// Some controls (eg ListView) have child windows.
				// Reflect those notifications too.
				CWnd* pWndFromParent = GetApp()->GetCWndFromMap(::GetParent(hwndFrom));
				if (pWndFromParent != NULL)
					lr = pWndFromParent->OnNotifyReflect(wParam, lParam);
			}

			// Handle user notifications
			if (!lr) lr = OnNotify(wParam, lParam);

			// Set the return code for notifications
			if (IsWindow())
				SetWindowLongPtr(DWLP_MSGRESULT, (LONG_PTR)lr);

			return (BOOL)lr;
		}

	case WM_PAINT:
		{
			if (::GetUpdateRect(m_hWnd, NULL, FALSE))
			{
				CPaintDC dc(this);
				OnDraw(&dc);
			}
			else
			// RedrawWindow can require repainting without an update rect
			{
				CClientDC dc(this);
				OnDraw(&dc);
			}

			break;
		}

	case WM_ERASEBKGND:
		{
			CDC dc((HDC)wParam);
			BOOL bResult = OnEraseBkgnd(&dc);
			dc.Detach();
			if (bResult) return TRUE;
		}
		break;

	// A set of messages to be reflected back to the control that generated them
	case WM_CTLCOLORBTN:
	case WM_CTLCOLOREDIT:
	case WM_CTLCOLORDLG:
	case WM_CTLCOLORLISTBOX:
	case WM_CTLCOLORSCROLLBAR:
	case WM_CTLCOLORSTATIC:
	case WM_DRAWITEM:
	case WM_MEASUREITEM:
	case WM_DELETEITEM:
	case WM_COMPAREITEM:
	case WM_CHARTOITEM:
	case WM_VKEYTOITEM:
	case WM_HSCROLL:
	case WM_VSCROLL:
	case WM_PARENTNOTIFY:
		return MessageReflect(m_hWnd, uMsg, wParam, lParam);

	} // switch(uMsg)
	return FALSE;

} // INT_PTR CALLBACK CDialog::DialogProc(...)

INT_PTR CDialog::DoModal()
{
	// Create a modal dialog
	// A modal dialog box must be closed by the user before the application continues

	assert( GetApp() );		// Test if Win32++ has been started
	assert(!::IsWindow(m_hWnd));	// Only one window per CWnd instance allowed

	INT_PTR nResult = 0;

	try
	{
		m_IsModal=TRUE;

		// Ensure this thread has the TLS index set
		TLSData* pTLSData = GetApp()->SetTlsIndex();

	#ifndef _WIN32_WCE
		BOOL IsHookedHere = FALSE;
		if (NULL == pTLSData->hHook )
		{
			pTLSData->hHook = ::SetWindowsHookEx(WH_MSGFILTER, (HOOKPROC)StaticMsgHook, NULL, ::GetCurrentThreadId());
			IsHookedHere = TRUE;
		}
	#endif

		HINSTANCE hInstance = GetApp()->GetInstanceHandle();
		pTLSData->pCWnd = this;

		// Create a modal dialog
		if (IsIndirect())
			nResult = ::DialogBoxIndirect(hInstance, m_lpTemplate, m_hParent, (DLGPROC)CDialog::StaticDialogProc);
		else
		{
			if (::FindResource(GetApp()->GetResourceHandle(), m_lpszResName, RT_DIALOG))
				hInstance = GetApp()->GetResourceHandle();
			nResult = ::DialogBox(hInstance, m_lpszResName, m_hParent, (DLGPROC)CDialog::StaticDialogProc);
		}

		// Tidy up
		m_hWnd = NULL;
		pTLSData->pCWnd = NULL;
		GetApp()->CleanupTemps();

	#ifndef _WIN32_WCE
		if (IsHookedHere)
		{
			::UnhookWindowsHookEx(pTLSData->hHook);
			pTLSData->hHook = NULL;
		}
	#endif

		if (nResult == -1)
			throw CWinException(_T("Failed to create modal dialog box"));

	}

	catch (const CWinException &e)
	{
		TRACE(_T("\n*** Failed to create dialog ***\n"));
		e.what();	// Display the last error message.

		// eat the exception (don't rethrow)
	}

	return nResult;
}

HWND CDialog::DoModeless()
{
	assert( GetApp() );		// Test if Win32++ has been started
	assert(!::IsWindow(m_hWnd));	// Only one window per CWnd instance allowed

	try
	{
		m_IsModal=FALSE;

		// Ensure this thread has the TLS index set
		TLSData* pTLSData = GetApp()->SetTlsIndex();

		// Store the CWnd pointer in Thread Local Storage
		pTLSData->pCWnd = this;

		HINSTANCE hInstance = GetApp()->GetInstanceHandle();

		// Create a modeless dialog
		if (IsIndirect())
			m_hWnd = ::CreateDialogIndirect(hInstance, m_lpTemplate, m_hParent, (DLGPROC)CDialog::StaticDialogProc);
		else
		{
			if (::FindResource(GetApp()->GetResourceHandle(), m_lpszResName, RT_DIALOG))
				hInstance = GetApp()->GetResourceHandle();

			m_hWnd = ::CreateDialog(hInstance, m_lpszResName, m_hParent, (DLGPROC)CDialog::StaticDialogProc);
		}

		// Tidy up
		pTLSData->pCWnd = NULL;

		// Now handle dialog creation failure
		if (!m_hWnd)
			throw CWinException(_T("Failed to create dialog"));
	}

	catch (const CWinException &e)
	{
		TRACE(_T("\n*** Failed to create dialog ***\n"));
		e.what();	// Display the last error message.

		// eat the exception (don't rethrow)
	}

	return m_hWnd;
}

void CDialog::EndDialog(INT_PTR nResult)
{
	assert(::IsWindow(m_hWnd));

	if (IsModal())
		::EndDialog(m_hWnd, nResult);
	else
		Destroy();

	m_hWnd = NULL;
}

void CDialog::OnCancel()
{
	// Override to customize OnCancel behaviour
	EndDialog(IDCANCEL);
}

BOOL CDialog::OnInitDialog()
{
	// Called when the dialog is initialized
	// Override it in your derived class to automatically perform tasks
	// The return value is used by WM_INITDIALOG

	return TRUE;
}

void CDialog::OnOK()
{
	// Override to customize OnOK behaviour
	if ( IsWindow() )
		EndDialog(IDOK);
}

BOOL CDialog::PreTranslateMessage(MSG* pMsg)
{
	// allow the dialog to translate keyboard input
	if ((pMsg->message >= WM_KEYFIRST) && (pMsg->message <= WM_KEYLAST))
	{
		// Process dialog keystrokes for modeless dialogs
		if (!IsModal())
		{
			TLSData* pTLSData = (TLSData*)TlsGetValue(GetApp()->GetTlsIndex());
			if (NULL == pTLSData->hHook)
			{
				if (IsDialogMessage(pMsg))
					return TRUE;
			}
			else
			{
				// A modal message loop is running so we can't do IsDialogMessage.
				// Avoid having modal dialogs create other windows, because those
				// windows will then use the modal dialog's special message loop.
				// If you need the dialog to create another window, put it in a
				// different thread.
			}
		}
	}

	return FALSE;
}

void CDialog::SetDlgParent(CWnd* pParent)
// Allows the parent of the dialog to be set before the dialog is created
{
	m_hParent = pParent? pParent->GetHwnd() : NULL;
}

INT_PTR CALLBACK CDialog::StaticDialogProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	// Find the CWnd pointer mapped to this HWND
	CDialog* w = (CDialog*)GetApp()->GetCWndFromMap(hWnd);
	if (0 == w)
	{
		// The HWND wasn't in the map, so add it now
		TLSData* pTLSData = (TLSData*)TlsGetValue(GetApp()->GetTlsIndex());
		assert(pTLSData);

		// Retrieve pointer to CWnd object from Thread Local Storage TLS
		w = (CDialog*)pTLSData->pCWnd;
		assert(w);
		pTLSData->pCWnd = NULL;

		// Store the Window pointer into the HWND map
		w->m_hWnd = hWnd;
		w->AddToMap();
	}

	return w->DialogProc(uMsg, wParam, lParam);

} // INT_PTR CALLBACK CDialog::StaticDialogProc(...)

#ifndef _WIN32_WCE
LRESULT CALLBACK CDialog::StaticMsgHook(int nCode, WPARAM wParam, LPARAM lParam)
{
	// Used by Modal Dialogs to PreTranslate Messages
	TLSData* pTLSData = (TLSData*)TlsGetValue(GetApp()->GetTlsIndex());

	if (nCode == MSGF_DIALOGBOX)
	{
		MSG* lpMsg = (MSG*) lParam;

		// only pre-translate keyboard events
		if ((lpMsg->message >= WM_KEYFIRST && lpMsg->message <= WM_KEYLAST))
		{
			for (HWND hWnd = lpMsg->hwnd; hWnd != NULL; hWnd = ::GetParent(hWnd))
			{
				CDialog* pDialog = (CDialog*)GetApp()->GetCWndFromMap(hWnd);
				if (pDialog && (lstrcmp(pDialog->GetClassName(), _T("#32770")) == 0))	// only for dialogs
				{
					pDialog->PreTranslateMessage(lpMsg);
					break;
				}
			}
		}
	}

	return ::CallNextHookEx(pTLSData->hHook, nCode, wParam, lParam);
}
#endif



#ifndef _WIN32_WCE

/////////////////////////////////////
// Definitions for the CResizer class
//

void CResizer::AddChild(CWnd* pWnd, Alignment corner, DWORD dwStyle)
// Adds a child window (usually a dialog control) to the set of windows managed by
// the Resizer.
//
// The alignment corner should be set to the closest corner of the dialog. Allowed
// values are topleft, topright, bottomleft, and bottomright.
// Set bFixedWidth to TRUE if the width should be fixed instead of variable.
// Set bFixedHeight to TRUE if the height should be fixed instead of variable.
{
	ResizeData rd;
	rd.corner = corner;
	rd.bFixedWidth  = !(dwStyle & RD_STRETCH_WIDTH);
	rd.bFixedHeight = !(dwStyle & RD_STRETCH_HEIGHT);
	CRect rcInit = pWnd->GetWindowRect();
	m_pParent->ScreenToClient(rcInit);
	rd.rcInit = rcInit;
	rd.hWnd = pWnd->GetHwnd();

	m_vResizeData.insert(m_vResizeData.begin(), rd);
}

void CResizer::AddChild(HWND hWnd, Alignment corner, DWORD dwStyle)
// Adds a child window (usually a dialog control) to the set of windows managed by
// the Resizer.	
{
	AddChild(FromHandle(hWnd), corner, dwStyle);
}

void CResizer::HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_SIZE:
		RecalcLayout();
		break;

	case WM_HSCROLL:
		if (0 == lParam)
			OnHScroll(wParam, lParam);
		break;

	case WM_VSCROLL:
		if (0 == lParam)
			OnVScroll(wParam, lParam);
		break;
	}
}

void CResizer::Initialize(CWnd* pParent, RECT rcMin, RECT rcMax)
// Sets up the Resizer by specifying the parent window (usually a dialog),
//  and the minimum and maximum allowed rectangle sizes.
{
	assert (NULL != pParent);

	m_pParent = pParent;
	m_rcInit = pParent->GetClientRect();
	m_rcMin = rcMin;
	m_rcMax = rcMax;

	// Add scroll bar support to the parent window
	DWORD dwStyle = (DWORD)m_pParent->GetClassLongPtr(GCL_STYLE);
	dwStyle |= WS_HSCROLL | WS_VSCROLL;
	m_pParent->SetClassLongPtr(GCL_STYLE, dwStyle);
}

void CResizer::OnHScroll(WPARAM wParam, LPARAM /*lParam*/)
{
	int xNewPos;

	switch (LOWORD(wParam))
	{
		case SB_PAGEUP: // User clicked the scroll bar shaft left of the scroll box.
			xNewPos = m_xScrollPos - 50;
			break;

		case SB_PAGEDOWN: // User clicked the scroll bar shaft right of the scroll box.
			xNewPos = m_xScrollPos + 50;
			break;

		case SB_LINEUP: // User clicked the left arrow.
			xNewPos = m_xScrollPos - 5;
			break;

		case SB_LINEDOWN: // User clicked the right arrow.
			xNewPos = m_xScrollPos + 5;
			break;

		case SB_THUMBPOSITION: // User dragged the scroll box.
			xNewPos = HIWORD(wParam);
			break;

		case SB_THUMBTRACK: // User dragging the scroll box.
			xNewPos = HIWORD(wParam);
			break;

		default:
			xNewPos = m_xScrollPos;
	}

	// Scroll the window.
	xNewPos = MAX(0, xNewPos);
	xNewPos = MIN( xNewPos, GetMinRect().Width() - m_pParent->GetClientRect().Width() );
	int xDelta = xNewPos - m_xScrollPos;
	m_xScrollPos = xNewPos;
	m_pParent->ScrollWindow(-xDelta, 0, NULL, NULL);

	// Reset the scroll bar.
	SCROLLINFO si = {0};
	si.cbSize = sizeof(si);
	si.fMask  = SIF_POS;
	si.nPos   = m_xScrollPos;
	m_pParent->SetScrollInfo(SB_HORZ, si, TRUE);
}

void CResizer::OnVScroll(WPARAM wParam, LPARAM /*lParam*/)
{
	int yNewPos;

	switch (LOWORD(wParam))
	{
		case SB_PAGEUP: // User clicked the scroll bar shaft above the scroll box.
			yNewPos = m_yScrollPos - 50;
			break;

		case SB_PAGEDOWN: // User clicked the scroll bar shaft below the scroll box.
			yNewPos = m_yScrollPos + 50;
			break;

		case SB_LINEUP: // User clicked the top arrow.
			yNewPos = m_yScrollPos - 5;
			break;

		case SB_LINEDOWN: // User clicked the bottom arrow.
			yNewPos = m_yScrollPos + 5;
			break;

		case SB_THUMBPOSITION: // User dragged the scroll box.
			yNewPos = HIWORD(wParam);
			break;

		case SB_THUMBTRACK: // User dragging the scroll box.
			yNewPos = HIWORD(wParam);
			break;

		default:
			yNewPos = m_yScrollPos;
	}

	// Scroll the window.
	yNewPos = MAX(0, yNewPos);
	yNewPos = MIN( yNewPos, GetMinRect().Height() - m_pParent->GetClientRect().Height() );
	int yDelta = yNewPos - m_yScrollPos;
	m_yScrollPos = yNewPos;
	m_pParent->ScrollWindow(0, -yDelta, NULL, NULL);

	// Reset the scroll bar.
	SCROLLINFO si = {0};
	si.cbSize = sizeof(si);
	si.fMask  = SIF_POS;
	si.nPos   = m_yScrollPos;
	m_pParent->SetScrollInfo(SB_VERT, si, TRUE);
}

void CResizer::RecalcLayout()
// Repositions the child windows. Call this function when handling
// the WM_SIZE message in the parent window.
{
	assert (m_rcInit.Width() > 0 && m_rcInit.Height() > 0);
	assert (NULL != m_pParent);

	CRect rcCurrent = m_pParent->GetClientRect();

	// Adjust the scrolling if required
	m_xScrollPos = MIN(m_xScrollPos, MAX(0, m_rcMin.Width()  - rcCurrent.Width() ) );
	m_yScrollPos = MIN(m_yScrollPos, MAX(0, m_rcMin.Height() - rcCurrent.Height()) );
	SCROLLINFO si = {0};
	si.cbSize = sizeof(si);
	si.fMask  = SIF_RANGE | SIF_PAGE | SIF_POS;
	si.nMax   =	m_rcMin.Width();
	si.nPage  = rcCurrent.Width();
	si.nPos   = m_xScrollPos;
	m_pParent->SetScrollInfo(SB_HORZ, si, TRUE);
	si.nMax   =	m_rcMin.Height();
	si.nPage  = rcCurrent.Height();
	si.nPos   = m_yScrollPos;
	m_pParent->SetScrollInfo(SB_VERT, si, TRUE);

	rcCurrent.right  = MAX( rcCurrent.Width(),  m_rcMin.Width() );
	rcCurrent.bottom = MAX( rcCurrent.Height(), m_rcMin.Height() );
	if (!m_rcMax.IsRectEmpty())
	{
		rcCurrent.right  = MIN( rcCurrent.Width(),  m_rcMax.Width() );
		rcCurrent.bottom = MIN( rcCurrent.Height(), m_rcMax.Height() );
	}

	// Declare an iterator to step through the vector
	std::vector<ResizeData>::iterator iter;

	for (iter = m_vResizeData.begin(); iter < m_vResizeData.end(); ++iter)
	{
		int left   = 0;
		int top    = 0;
		int width  = 0;
		int height = 0;

		// Calculate the new size and position of the child window
		switch( (*iter).corner )
		{
		case topleft:
			width  = (*iter).bFixedWidth?  (*iter).rcInit.Width()  : (*iter).rcInit.Width()  - m_rcInit.Width() + rcCurrent.Width();
			height = (*iter).bFixedHeight? (*iter).rcInit.Height() : (*iter).rcInit.Height() - m_rcInit.Height() + rcCurrent.Height();
			left   = (*iter).rcInit.left;
			top    = (*iter).rcInit.top;
			break;
		case topright:
			width  = (*iter).bFixedWidth?  (*iter).rcInit.Width()  : (*iter).rcInit.Width()  - m_rcInit.Width() + rcCurrent.Width();
			height = (*iter).bFixedHeight? (*iter).rcInit.Height() : (*iter).rcInit.Height() - m_rcInit.Height() + rcCurrent.Height();
			left   = (*iter).rcInit.right - width - m_rcInit.Width() + rcCurrent.Width();
			top    = (*iter).rcInit.top;
			break;
		case bottomleft:
			width  = (*iter).bFixedWidth?  (*iter).rcInit.Width()  : (*iter).rcInit.Width()  - m_rcInit.Width() + rcCurrent.Width();
			height = (*iter).bFixedHeight? (*iter).rcInit.Height() : (*iter).rcInit.Height() - m_rcInit.Height() + rcCurrent.Height();
			left   = (*iter).rcInit.left;
			top    = (*iter).rcInit.bottom - height - m_rcInit.Height() + rcCurrent.Height();
			break;
		case bottomright:
			width  = (*iter).bFixedWidth?  (*iter).rcInit.Width()  : (*iter).rcInit.Width()  - m_rcInit.Width() + rcCurrent.Width();
			height = (*iter).bFixedHeight? (*iter).rcInit.Height() : (*iter).rcInit.Height() - m_rcInit.Height() + rcCurrent.Height();
			left   = (*iter).rcInit.right   - width - m_rcInit.Width() + rcCurrent.Width();
			top    = (*iter).rcInit.bottom  - height - m_rcInit.Height() + rcCurrent.Height();
			break;
		}

		// Position the child window.
		CRect rc(left - m_xScrollPos, top - m_yScrollPos, left + width - m_xScrollPos, top + height - m_yScrollPos);
		if ( rc != (*iter).rcOld)
		{
			CWnd* pWnd = FromHandle((*iter).hWnd);
			CWnd *pWndPrev = pWnd->GetWindow(GW_HWNDPREV); // Trick to maintain the original tab order.
		//	HWND hWnd = pWndPrev ? pWndPrev->GetHwnd():NULL;
			pWnd->SetWindowPos(pWndPrev, rc, SWP_NOCOPYBITS);
			(*iter).rcOld = rc;
		}
	}
}

#endif // #ifndef _WIN32_WCE
