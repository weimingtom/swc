#pragma once

//#include "wincore.h"
#include "wincore_head.h"
#include "CWnd.h"

class CStatusBar : public CWnd
{
public:
	CStatusBar();
	virtual ~CStatusBar() {}

// Overridables
	virtual void PreCreate(CREATESTRUCT& cs);
	virtual void PreRegisterClass(WNDCLASS &wc);

// Attributes
	int GetParts();
	HICON GetPartIcon(int iPart);
	CRect GetPartRect(int iPart);
	CString GetPartText(int iPart) const;
	BOOL IsSimple();
	BOOL SetPartIcon(int iPart, HICON hIcon);
	BOOL SetPartText(int iPart, LPCTSTR szText, UINT Style = 0) const;
	BOOL SetPartWidth(int iPart, int iWidth) const;

// Operations
	CStatusBar(const CStatusBar&);				// Disable copy construction
	CStatusBar& operator = (const CStatusBar&); // Disable assignment operator

	BOOL CreateParts(int iParts, const int iPaneWidths[]) const;
	void SetSimple(BOOL fSimple = TRUE);
};
