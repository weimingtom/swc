#pragma once

#include "wincore_head.h"
#include "CCriticalSection.h"

class CWinApp
{
	friend class CDC;
	friend class CDialog;
	friend class CGDIObject;
	friend class CMenu;
	friend class CMenuBar;
	friend class CPropertyPage;
	friend class CPropertySheet;
	friend class CTaskDialog;
	friend class CWnd;
	friend CWinApp* GetApp();
	friend CGDIObject* FromHandle(HGDIOBJ hObject);
	friend CBitmap* FromHandle(HBITMAP hBitmap);
	friend CBrush* FromHandle(HBRUSH hBrush);
	friend CFont* FromHandle(HFONT hFont);
	friend CPalette* FromHandle(HPALETTE hPalette);
	friend CPen* FromHandle(HPEN hPen);
	friend CRgn* FromHandle(HRGN hRgn);
	friend CDC* FromHandle(HDC hDC);
	friend CWnd* FromHandle(HWND hWnd);
#ifndef _WIN32_WCE
	friend CMenu* FromHandle(HMENU hMenu);
#endif

	typedef Shared_Ptr<TLSData> TLSDataPtr;

public:
	CWinApp();
	virtual ~CWinApp();

	HACCEL GetAccelerators() const { return m_hAccel; }
	HINSTANCE GetInstanceHandle() const { return m_hInstance; }
	HINSTANCE GetResourceHandle() const { return (m_hResource ? m_hResource : m_hInstance); }
	void SetAccelerators(HACCEL hAccel, CWnd* pWndAccel);
	void SetResourceHandle(HINSTANCE hResource);

	// These are the functions you might wish to override
	virtual BOOL InitInstance();
	virtual int  MessageLoop();
	virtual BOOL OnIdle(LONG lCount);
	virtual BOOL PreTranslateMessage(MSG Msg);
	virtual int Run();

private:
	CWinApp(const CWinApp&);				// Disable copy construction
	CWinApp& operator = (const CWinApp&);	// Disable assignment operator
	CDC* GetCDCFromMap(HDC hDC);
	CGDIObject* GetCGDIObjectFromMap(HGDIOBJ hObject);
	CMenu* GetCMenuFromMap(HMENU hMenu);
	CWnd* GetCWndFromMap(HWND hWnd);

	void	AddTmpDC(CDC* pDC);
	void	AddTmpGDI(CGDIObject* pObject);
	CMenu*	AddTmpMenu(HMENU hMenu);
	CWnd*	AddTmpWnd(HWND hWnd);
	void	CleanupTemps();
	DWORD	GetTlsIndex() const {return m_dwTlsIndex;}
	void	SetCallback();
	TLSData* SetTlsIndex();
	static CWinApp* SetnGetThis(CWinApp* pThis = 0);

	std::map<HDC, CDC*, CompareHDC> m_mapHDC;			// maps device context handles to CDC objects
	std::map<HGDIOBJ, CGDIObject*, CompareGDI> m_mapGDI;	// maps GDI handles to CGDIObjects.
	std::map<HMENU, CMenu*, CompareHMENU> m_mapHMENU;	// maps menu handles to CMenu objects
	std::map<HWND, CWnd*, CompareHWND> m_mapHWND;		// maps window handles to CWnd objects
	std::vector<TLSDataPtr> m_vTLSData;		// vector of TLSData smart pointers, one for each thread
	CCriticalSection m_csMapLock;	// thread synchronisation for m_mapHWND
	CCriticalSection m_csTLSLock;	// thread synchronisation for m_vTLSData
	CCriticalSection m_csAppStart;	// thread synchronisation for application startup
	HINSTANCE m_hInstance;			// handle to the applications instance
	HINSTANCE m_hResource;			// handle to the applications resources
	DWORD m_dwTlsIndex;				// Thread Local Storage index
	WNDPROC m_Callback;				// callback address of CWnd::StaticWndowProc
	HACCEL m_hAccel;				// handle to the accelerator table
	CWnd* m_pWndAccel;				// handle to the window for accelerator keys
};
