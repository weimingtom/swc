#include "statusbar.h"

CStatusBar::CStatusBar()
{
}

BOOL CStatusBar::CreateParts(int iParts, const int iPaneWidths[]) const
// Sets the number of parts in a status window and the coordinate of the right edge of each part. 
// If an element of iPaneWidths is -1, the right edge of the corresponding part extends
//  to the border of the window
{
	assert(::IsWindow(m_hWnd));
	assert(iParts <= 256);	
	
	return (BOOL)SendMessage(SB_SETPARTS, iParts, (LPARAM)iPaneWidths);		
}

int CStatusBar::GetParts()
{
	assert(::IsWindow(m_hWnd));
	return (int)SendMessage(SB_GETPARTS, 0L, 0L);
}

HICON CStatusBar::GetPartIcon(int iPart)
{
	assert(::IsWindow(m_hWnd));
	return (HICON)SendMessage(SB_GETICON, (WPARAM)iPart, 0L);
}

CRect CStatusBar::GetPartRect(int iPart)
{
	assert(::IsWindow(m_hWnd));
	
	CRect rc;
	SendMessage(SB_GETRECT, (WPARAM)iPart, (LPARAM)&rc);
	return rc;
}

CString CStatusBar::GetPartText(int iPart) const
{
	assert(::IsWindow(m_hWnd));
	CString PaneText;
	
	// Get size of Text array
	int iChars = LOWORD (SendMessage(SB_GETTEXTLENGTH, iPart, 0L));

	std::vector<TCHAR> Text( iChars +1, _T('\0') );
	TCHAR* pTextArray = &Text[0];

	SendMessage(SB_GETTEXT, iPart, (LPARAM)pTextArray);
	PaneText = pTextArray;			
	return PaneText;
}

BOOL CStatusBar::IsSimple()
{
	assert(::IsWindow(m_hWnd));
	return (BOOL)SendMessage(SB_ISSIMPLE, 0L, 0L);
}

void CStatusBar::PreCreate(CREATESTRUCT &cs)
{
	cs.style = WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | CCS_BOTTOM | SBARS_SIZEGRIP;
}

void CStatusBar::PreRegisterClass(WNDCLASS &wc)
{
	// Set the Window Class
	wc.lpszClassName =  STATUSCLASSNAME;
}

BOOL CStatusBar::SetPartText(int iPart, LPCTSTR szText, UINT Style) const
// Available Styles: Combinations of ...
//0					The text is drawn with a border to appear lower than the plane of the window.
//SBT_NOBORDERS		The text is drawn without borders.
//SBT_OWNERDRAW		The text is drawn by the parent window.
//SBT_POPOUT		The text is drawn with a border to appear higher than the plane of the window.
//SBT_RTLREADING	The text will be displayed in the opposite direction to the text in the parent window.
{
	assert(::IsWindow(m_hWnd));
	
	BOOL bResult = FALSE;
	if (SendMessage(SB_GETPARTS, 0L, 0L) >= iPart)
		bResult = (BOOL)SendMessage(SB_SETTEXT, iPart | Style, (LPARAM)szText);

	return bResult;
}

BOOL CStatusBar::SetPartIcon(int iPart, HICON hIcon)
{
	assert(::IsWindow(m_hWnd));
	return (BOOL)SendMessage(SB_SETICON, (WPARAM)iPart, (LPARAM) hIcon);
}

BOOL CStatusBar::SetPartWidth(int iPart, int iWidth) const
{
	// This changes the width of an existing pane, or creates a new pane
	// with the specified width.
	// A width of -1 for the last part sets the width to the border of the window.

	assert(::IsWindow(m_hWnd));
	assert(iPart >= 0 && iPart <= 255);

	// Fill the PartWidths vector with the current width of the statusbar parts
	int PartsCount = (int)SendMessage(SB_GETPARTS, 0L, 0L);
	std::vector<int> PartWidths(PartsCount, 0);
	int* pPartWidthArray = &PartWidths[0];
	SendMessage(SB_GETPARTS, PartsCount, (LPARAM)pPartWidthArray);

	// Fill the NewPartWidths vector with the new width of the statusbar parts
	int NewPartsCount = MAX(iPart+1, PartsCount);	
	std::vector<int> NewPartWidths(NewPartsCount, 0);;
	NewPartWidths = PartWidths;
	int* pNewPartWidthArray = &NewPartWidths[0];
	
	if (0 == iPart)
		pNewPartWidthArray[iPart] = iWidth;
	else
	{
		if (iWidth >= 0)
			pNewPartWidthArray[iPart] = pNewPartWidthArray[iPart -1] + iWidth;
		else
			pNewPartWidthArray[iPart] = -1;
	}

	// Set the statusbar parts with our new parts count and part widths
	BOOL bResult = (BOOL)SendMessage(SB_SETPARTS, NewPartsCount, (LPARAM)pNewPartWidthArray);

	return bResult;
}

void CStatusBar::SetSimple(BOOL fSimple /* = TRUE*/)
{
	assert(::IsWindow(m_hWnd));
	SendMessage(SB_SIMPLE, (WPARAM)fSimple, 0L);
}
