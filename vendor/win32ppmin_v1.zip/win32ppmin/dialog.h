#pragma once

#include "wincore_head.h"
#include "CWnd.h"

#ifndef SWP_NOCOPYBITS
	#define SWP_NOCOPYBITS      0x0100
#endif

#define IDLE_TIMER_ID 300

class CDialog : public CWnd
{
public:
	CDialog(UINT nResID, CWnd* pParent = NULL);
	CDialog(LPCTSTR lpszResName, CWnd* pParent = NULL);
	CDialog(LPCDLGTEMPLATE lpTemplate, CWnd* pParent = NULL);
	virtual ~CDialog();

	// You probably won't need to override these functions
	virtual void AttachItem(int nID, CWnd& Wnd);
	virtual HWND Create(CWnd* pParent = NULL);
	virtual INT_PTR DoModal();
	virtual HWND DoModeless();
	virtual void SetDlgParent(CWnd* pParent);
	BOOL IsModal() const { return m_IsModal; }
	BOOL IsIndirect() const { return (NULL != m_lpTemplate); }

protected:
	// These are the functions you might wish to override
	virtual INT_PTR DialogProc(UINT uMsg, WPARAM wParam, LPARAM lParam);
	virtual INT_PTR DialogProcDefault(UINT uMsg, WPARAM wParam, LPARAM lParam);
	virtual void EndDialog(INT_PTR nResult);
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	// Can't override these functions
	static INT_PTR CALLBACK StaticDialogProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

#ifndef _WIN32_WCE
	static LRESULT CALLBACK StaticMsgHook(int nCode, WPARAM wParam, LPARAM lParam);
#endif

private:
	CDialog(const CDialog&);			  // Disable copy construction
	CDialog& operator = (const CDialog&); // Disable assignment operator

	BOOL m_IsModal;					// a flag for modal dialogs
	LPCTSTR m_lpszResName;			// the resource name for the dialog
	LPCDLGTEMPLATE m_lpTemplate;	// the dialog template for indirect dialogs
	HWND m_hParent;					// handle to the dialogs's parent window
};


#ifndef _WIN32_WCE

//////////////////////////////////////
// Declaration of the CResizer class
//
// The CResizer class can be used to rearrange a dialog's child
// windows when the dialog is resized.

// To use CResizer, follow the following steps:
// 1) Use Initialize to specify the dialog's CWnd, and min and max size.
// 3) Use AddChild for each child window
// 4) Call HandleMessage from within DialogProc.
//

// Resize Dialog Styles
#define RD_STRETCH_WIDTH		0x0001	// The item has a variable width
#define RD_STRETCH_HEIGHT		0x0002	// The item has a variable height

// Resize Dialog alignments
enum Alignment { topleft, topright, bottomleft, bottomright };

class CResizer
{
public:
	CResizer() : m_pParent(0), m_xScrollPos(0), m_yScrollPos(0) {}
	virtual ~CResizer() {}

	virtual void AddChild(CWnd* pWnd, Alignment corner, DWORD dwStyle);
	virtual void AddChild(HWND hWnd, Alignment corner, DWORD dwStyle);
	virtual void HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam);
	virtual void Initialize(CWnd* pParent, RECT rcMin, RECT rcMax = CRect(0,0,0,0));
	virtual void OnHScroll(WPARAM wParam, LPARAM lParam);
	virtual void OnVScroll(WPARAM wParam, LPARAM lParam);
	virtual void RecalcLayout();
	CRect GetMinRect() const { return m_rcMin; }
	CRect GetMaxRect() const { return m_rcMax; }

	struct ResizeData
	{
		CRect rcInit;
		CRect rcOld;
		Alignment corner;
		BOOL bFixedWidth;
		BOOL bFixedHeight;
		HWND hWnd;
	};

private:
	CWnd* m_pParent;
	std::vector<ResizeData> m_vResizeData;

	CRect m_rcInit;
	CRect m_rcMin;
	CRect m_rcMax;

	int m_xScrollPos;
	int m_yScrollPos;
};

#endif
