#include "menu.h"
#include "winutils.h"

CMenu::~CMenu()
{
	if (m_hMenu)
	{	
		if (!m_IsTmpMenu)
		{
			::DestroyMenu(m_hMenu);
		}
		
		RemoveFromMap();
	}

	m_vSubMenus.clear();
}

void CMenu::AddToMap()
// Store the HMENU and CMenu pointer in the HMENU map
{
	assert( GetApp() );
	assert(m_hMenu);
	
	GetApp()->m_csMapLock.Lock();
	GetApp()->m_mapHMENU.insert(std::make_pair(m_hMenu, this));
	GetApp()->m_csMapLock.Release();
}

BOOL CMenu::RemoveFromMap()
{
	BOOL Success = FALSE;

	if (GetApp())
	{
		// Allocate an iterator for our HDC map
		std::map<HMENU, CMenu*, CompareHMENU>::iterator m;

		CWinApp* pApp = GetApp();
		if (pApp)
		{
			// Erase the CDC pointer entry from the map
			pApp->m_csMapLock.Lock();
			for (m = pApp->m_mapHMENU.begin(); m != pApp->m_mapHMENU.end(); ++m)
			{
				if (this == m->second)
				{
					pApp->m_mapHMENU.erase(m);
					Success = TRUE;
					break;
				}
			}

			pApp->m_csMapLock.Release();
		}
	}

	return Success;
}


BOOL CMenu::AppendMenu(UINT uFlags, UINT_PTR uIDNewItem /*= 0*/, LPCTSTR lpszNewItem /*= NULL*/)
// Appends a new item to the end of the specified menu bar, drop-down menu, submenu, or shortcut menu.
{
	assert(IsMenu(m_hMenu));
	return ::AppendMenu(m_hMenu, uFlags, uIDNewItem, lpszNewItem);
}

BOOL CMenu::AppendMenu(UINT uFlags, UINT_PTR uIDNewItem, const CBitmap* pBmp)
// Appends a new item to the end of the specified menu bar, drop-down menu, submenu, or shortcut menu.
{
	assert(IsMenu(m_hMenu));
	assert(pBmp);
	return ::AppendMenu(m_hMenu, uFlags, uIDNewItem, (LPCTSTR)pBmp->GetHandle());
}

void CMenu::Attach(HMENU hMenu)
// Attaches an existing menu to this CMenu
{
	if (m_hMenu != NULL && m_hMenu != hMenu)
	{
		::DestroyMenu(Detach());
	}

	if (hMenu)
	{
		m_hMenu = hMenu;
		AddToMap();
	}
}

UINT CMenu::CheckMenuItem(UINT uIDCheckItem, UINT uCheck)
// Sets the state of the specified menu item's check-mark attribute to either selected or clear.
{
	assert(IsMenu(m_hMenu));
	return ::CheckMenuItem(m_hMenu, uIDCheckItem, uCheck);
}

BOOL CMenu::CheckMenuRadioItem(UINT uIDFirst, UINT uIDLast, UINT uIDItem, UINT uFlags)
// Checks a specified menu item and makes it a radio item. At the same time, the function clears 
//  all other menu items in the associated group and clears the radio-item type flag for those items.
{
	assert(IsMenu(m_hMenu));
	return ::CheckMenuRadioItem(m_hMenu, uIDFirst, uIDLast, uIDItem, uFlags);
}	

void CMenu::CreateMenu()
// Creates an empty menu.
{
	assert(NULL == m_hMenu);
	m_hMenu = ::CreateMenu();
	AddToMap();
}

void CMenu::CreatePopupMenu()
// Creates a drop-down menu, submenu, or shortcut menu. The menu is initially empty.
{
	assert(NULL == m_hMenu);
	m_hMenu = ::CreatePopupMenu();
	AddToMap();
}

BOOL CMenu::DeleteMenu(UINT uPosition, UINT uFlags)
// Deletes an item from the specified menu.
{
	assert(IsMenu(m_hMenu));
	return ::DeleteMenu(m_hMenu, uPosition, uFlags);
}	

void CMenu::DestroyMenu()
// Destroys the menu and frees any memory that the menu occupies.
{
	if (::IsMenu(m_hMenu)) 
		::DestroyMenu(m_hMenu);
	
	m_hMenu = 0;
	RemoveFromMap();
	m_vSubMenus.clear();
}

HMENU CMenu::Detach()
// Detaches the HMENU from this CMenu. If the HMENU is not detached it will be 
// destroyed when this CMenu is deconstructed.
{
	assert(IsMenu(m_hMenu));
	HMENU hMenu = m_hMenu;
	m_hMenu = 0;
	RemoveFromMap();
	m_vSubMenus.clear();
	return hMenu;
}

HMENU CMenu::GetHandle() const
// Returns the HMENU assigned to this CMenu
{
	return m_hMenu;
}

UINT CMenu::EnableMenuItem(UINT uIDEnableItem, UINT uEnable)
// Enables, disables, or grays the specified menu item.
// The uEnable parameter must be a combination of either MF_BYCOMMAND or MF_BYPOSITION
// and MF_ENABLED, MF_DISABLED, or MF_GRAYED.
{
	assert(IsMenu(m_hMenu));
	return ::EnableMenuItem(m_hMenu, uIDEnableItem, uEnable);
}

UINT CMenu::GetDefaultItem(UINT gmdiFlags, BOOL fByPos /*= FALSE*/)
// Determines the default menu item.
// The gmdiFlags parameter specifies how the function searches for menu items. 
// This parameter can be zero or more of the following values: GMDI_GOINTOPOPUPS; GMDI_USEDISABLED.
{
	assert(IsMenu(m_hMenu));
	return ::GetMenuDefaultItem(m_hMenu, fByPos, gmdiFlags);
}

DWORD CMenu::GetMenuContextHelpId() const
// Retrieves the Help context identifier associated with the menu.
{
	assert(IsMenu(m_hMenu));
	return ::GetMenuContextHelpId(m_hMenu);
}

#if(WINVER >= 0x0500)
// minimum OS required : Win2000

BOOL CMenu::GetMenuInfo(LPMENUINFO lpcmi) const
// Retrieves the menu information.
{
	assert(IsMenu(m_hMenu));
	return ::GetMenuInfo(m_hMenu, lpcmi);
}

BOOL CMenu::SetMenuInfo(LPCMENUINFO lpcmi)
// Sets the menu information from the specified MENUINFO structure.
{
	assert(IsMenu(m_hMenu));
	return ::SetMenuInfo(m_hMenu, lpcmi);
}

#endif

UINT CMenu::GetMenuItemCount() const
// Retrieves the number of menu items.
{
	assert(IsMenu(m_hMenu));
	return ::GetMenuItemCount(m_hMenu);
}

UINT CMenu::GetMenuItemID(int nPos) const
// Retrieves the menu item identifier of a menu item located at the specified position
{
	assert(IsMenu(m_hMenu));
	return ::GetMenuItemID(m_hMenu, nPos);
}

BOOL CMenu::GetMenuItemInfo(UINT uItem, LPMENUITEMINFO lpMenuItemInfo, BOOL fByPos /*= FALSE*/)
// retrieves information about the specified menu item.
{
	assert(IsMenu(m_hMenu));
	assert(lpMenuItemInfo);
	lpMenuItemInfo->cbSize = GetSizeofMenuItemInfo();
	return ::GetMenuItemInfo(m_hMenu, uItem, fByPos, lpMenuItemInfo);
}

UINT CMenu::GetMenuState(UINT uID, UINT uFlags) const
// Retrieves the menu flags associated with the specified menu item.
// Possible values for uFlags are: MF_BYCOMMAND (default) or MF_BYPOSITION.
{
	assert(IsMenu(m_hMenu));
	return ::GetMenuState(m_hMenu, uID, uFlags);
}

int CMenu::GetMenuString(UINT uIDItem, LPTSTR lpString, int nMaxCount, UINT uFlags) const
// Copies the text string of the specified menu item into the specified buffer.
{
	assert(IsMenu(m_hMenu));
	assert(lpString);
	return ::GetMenuString(m_hMenu, uIDItem, lpString, nMaxCount, uFlags);
}

int CMenu::GetMenuString(UINT uIDItem, CString& rString, UINT uFlags) const
// Copies the text string of the specified menu item into the specified buffer.
{
	assert(IsMenu(m_hMenu));
	return ::GetMenuString(m_hMenu, uIDItem, (LPTSTR)rString.c_str(), rString.GetLength(), uFlags);
}

CMenu* CMenu::GetSubMenu(int nPos)
// Retrieves the CMenu object of a pop-up menu.
{
	assert(IsMenu(m_hMenu));
	CMenu* pMenu = new CMenu;
	pMenu->m_hMenu = ::GetSubMenu(m_hMenu, nPos);
	pMenu->m_IsTmpMenu = TRUE;
	m_vSubMenus.push_back(pMenu);
	return pMenu;
}

BOOL CMenu::InsertMenu(UINT uPosition, UINT uFlags, UINT_PTR uIDNewItem /*= 0*/, LPCTSTR lpszNewItem /*= NULL*/)
// Inserts a new menu item into a menu, moving other items down the menu.
{
	assert(IsMenu(m_hMenu));
	return ::InsertMenu(m_hMenu, uPosition, uFlags, uIDNewItem, lpszNewItem);
}

BOOL CMenu::InsertMenu(UINT uPosition, UINT uFlags, UINT_PTR uIDNewItem, const CBitmap* pBmp)
// Inserts a new menu item into a menu, moving other items down the menu.
{
	assert(IsMenu(m_hMenu));
	return ::InsertMenu(m_hMenu, uPosition, uFlags, uIDNewItem, (LPCTSTR)pBmp->GetHandle());
}

BOOL CMenu::InsertMenuItem(UINT uItem, LPMENUITEMINFO lpMenuItemInfo, BOOL fByPos /*= FALSE*/)
// Inserts a new menu item at the specified position in a menu.
{
	assert(IsMenu(m_hMenu));
	assert(lpMenuItemInfo);
	lpMenuItemInfo->cbSize = GetSizeofMenuItemInfo();
	return ::InsertMenuItem(m_hMenu, uItem, fByPos, lpMenuItemInfo);
}

BOOL CMenu::LoadMenu(LPCTSTR lpszResourceName)
// Loads the menu from the specified windows resource.
{
	assert(NULL == m_hMenu);
	assert(lpszResourceName);
	m_hMenu = ::LoadMenu(GetApp()->GetResourceHandle(), lpszResourceName);
	if (m_hMenu) AddToMap();
	return NULL != m_hMenu;
}

BOOL CMenu::LoadMenu(UINT uIDResource)
// Loads the menu from the specified windows resource.
{
	assert(NULL == m_hMenu);
	m_hMenu = ::LoadMenu(GetApp()->GetResourceHandle(), MAKEINTRESOURCE(uIDResource));
	if (m_hMenu) AddToMap();
	return NULL != m_hMenu;
}

BOOL CMenu::LoadMenuIndirect(const void* lpMenuTemplate)
// Loads the specified menu template and assigns it to this CMenu.
{
	assert(NULL == m_hMenu);
	assert(lpMenuTemplate);
	m_hMenu = ::LoadMenuIndirect(lpMenuTemplate);
	if (m_hMenu) AddToMap();
	return NULL != m_hMenu;
}	

BOOL CMenu::ModifyMenu(UINT uPosition, UINT uFlags, UINT_PTR uIDNewItem /*= 0*/, LPCTSTR lpszNewItem /*= NULL*/)
// Changes an existing menu item. This function is used to specify the content, appearance, and behavior of the menu item.
{
	assert(IsMenu(m_hMenu));
	return ::ModifyMenu(m_hMenu, uPosition, uFlags, uIDNewItem, lpszNewItem);
}

BOOL CMenu::ModifyMenu(UINT uPosition, UINT uFlags, UINT_PTR uIDNewItem, const CBitmap* pBmp)
// Changes an existing menu item. This function is used to specify the content, appearance, and behavior of the menu item.
{
	assert(IsMenu(m_hMenu));
	assert(pBmp);
	return ::ModifyMenu(m_hMenu, uPosition, uFlags, uIDNewItem, (LPCTSTR)pBmp->GetHandle());
}

BOOL CMenu::RemoveMenu(UINT uPosition, UINT uFlags)
// Deletes a menu item or detaches a submenu from the menu.
{
	assert(IsMenu(m_hMenu));
	return ::RemoveMenu(m_hMenu, uPosition, uFlags);
}

BOOL CMenu::SetDefaultItem(UINT uItem, BOOL fByPos /*= FALSE*/)
//  sets the default menu item for the menu.
{
	assert(IsMenu(m_hMenu));
	return ::SetMenuDefaultItem(m_hMenu, uItem, fByPos);
}

BOOL CMenu::SetMenuContextHelpId(DWORD dwContextHelpId)
// Associates a Help context identifier with the menu.
{
	assert(IsMenu(m_hMenu));
	return ::SetMenuContextHelpId(m_hMenu, dwContextHelpId);
}

BOOL CMenu::SetMenuItemBitmaps(UINT uPosition, UINT uFlags, const CBitmap* pBmpUnchecked, const CBitmap* pBmpChecked)
// Associates the specified bitmap with a menu item.
{
	assert(IsMenu(m_hMenu));
	return ::SetMenuItemBitmaps(m_hMenu, uPosition, uFlags, *pBmpUnchecked, *pBmpChecked);
}

BOOL CMenu::SetMenuItemInfo(UINT uItem, LPMENUITEMINFO lpMenuItemInfo, BOOL fByPos /*= FALSE*/)
// Changes information about a menu item.
{
	assert(IsMenu(m_hMenu));
	assert(lpMenuItemInfo);
	lpMenuItemInfo->cbSize = GetSizeofMenuItemInfo();
	return ::SetMenuItemInfo(m_hMenu, uItem, fByPos, lpMenuItemInfo);
}
	
BOOL CMenu::TrackPopupMenu(UINT uFlags, int x, int y, CWnd* pWnd, LPCRECT lpRect /*= 0*/)
// Displays a shortcut menu at the specified location and tracks the selection of items on the menu.
{
	assert(IsMenu(m_hMenu));
	HWND hWnd = pWnd? pWnd->GetHwnd() : 0;
	return ::TrackPopupMenu(m_hMenu, uFlags, x, y, 0, hWnd, lpRect);
}

BOOL CMenu::TrackPopupMenuEx(UINT uFlags, int x, int y, CWnd* pWnd, LPTPMPARAMS lptpm)
// Displays a shortcut menu at the specified location and tracks the selection of items on the shortcut menu.
{
	assert(IsMenu(m_hMenu));
	HWND hWnd = pWnd? pWnd->GetHwnd() : 0;
	return ::TrackPopupMenuEx(m_hMenu, uFlags, x, y, hWnd, lptpm);
}

BOOL CMenu::operator != (const CMenu& menu) const
// Returns TRUE if the two menu objects are not equal.
{
	return menu.m_hMenu != m_hMenu;
}

BOOL CMenu::operator == (const CMenu& menu) const
// Returns TRUE of the two menu object are equal
{
	return menu.m_hMenu == m_hMenu;
}

CMenu::operator HMENU () const
// Retrieves the menu's handle.
{
	return m_hMenu;
}
