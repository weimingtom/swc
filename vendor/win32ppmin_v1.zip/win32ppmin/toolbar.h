#pragma once

//#include "wincore.h"
#include "gdi.h"
#include "rebar.h"

struct ToolBarTheme
{
	BOOL UseThemes;			// TRUE if themes are used
	COLORREF clrHot1;		// Colour 1 for hot button
	COLORREF clrHot2;		// Colour 2 for hot button
	COLORREF clrPressed1;	// Colour 1 for pressed button
	COLORREF clrPressed2;	// Colour 2 for pressed button
	COLORREF clrOutline;	// Colour for border outline
};


////////////////////////////////////
// Declaration of the CToolBar class
//
class CToolBar : public CWnd
{
public:
	CToolBar();
	virtual ~CToolBar();

	// Operations
	virtual int  AddBitmap(UINT ToolBarID);
	virtual BOOL AddButton(UINT nID, BOOL bEnabled = TRUE);
	virtual void Destroy();
	virtual BOOL ReplaceBitmap(UINT NewToolBarID);
	virtual BOOL SetBitmap(UINT nID);
	virtual int  SetButtons(const std::vector<UINT>& vToolBarData) const;
	virtual BOOL SetButtonText(int idButton, LPCTSTR szText);
	virtual BOOL SetImages(COLORREF crMask, UINT ToolBarID, UINT ToolBarHotID, UINT ToolBarDisabledID);

	// Wrappers for Win32 API functions
	BOOL  AddButtons(UINT uNumButtons, LPTBBUTTON lpButtons) const;
	int   AddString(UINT nStringID) const;
	int   AddStrings(LPCTSTR lpszStrings) const;
	void  Autosize() const;
	void  CheckButton(int idButton, BOOL fCheck) const;
	int   CommandToIndex(int idButton) const;
	BOOL  DeleteButton(int iButton) const;
	BOOL  DisableButton(int idButton) const;
	BOOL  EnableButton(int idButton) const;
	BOOL  GetButton(int iButton, LPTBBUTTON lpButton) const;
	int   GetButtonCount() const;
	DWORD GetButtonSize() const;
	UINT  GetButtonState(int idButton) const;
	BYTE  GetButtonStyle(int idButton) const;
	CString GetButtonText(int idButton) const;
	int   GetCommandID(int iIndex) const;
	HIMAGELIST GetDisabledImageList() const;
	int   GetHotItem() const;
	HIMAGELIST GetHotImageList() const;
	HIMAGELIST GetImageList() const;
	CRect GetItemRect(int iIndex) const;
	CSize GetMaxSize() const;
	DWORD GetPadding() const;
	CRect GetRect(int idButton) const;
	int   GetRows() const;
	int   GetTextRows() const;
	CToolTip*  GetToolTips() const;
	BOOL  HasText() const;
	BOOL  HideButton(int idButton, BOOL fShow) const;
	int   HitTest() const;
	BOOL  Indeterminate(int idButton, BOOL fIndeterminate) const;
	BOOL  InsertButton(int iButton, LPTBBUTTON lpButton) const;
	BOOL  IsButtonHidden(int idButton) const;
	BOOL  IsButtonHighlighted(int idButton) const;
	BOOL  IsButtonIndeterminate(int idButton) const;
	BOOL  IsButtonPressed(int idButton) const;
	int   MapAccelerator(TCHAR chAccel) const;
	BOOL  MarkButton(int idButton) const;
	BOOL  MoveButton(UINT uOldPos, UINT uNewPos) const;
	BOOL  PressButton(int idButton, BOOL fPress) const;
	void  SaveRestore(BOOL fSave, TBSAVEPARAMS* ptbsp) const;
	BOOL  SetBitmapSize(int cx, int cy) const;
	BOOL  SetButtonSize(int cx, int cy) const;
	BOOL  SetButtonState(int idButton, UINT State) const;
	BOOL  SetButtonStyle(int idButton, BYTE Style) const;
	BOOL  SetButtonWidth(int idButton, int nWidth) const;
	BOOL  SetCommandID(int iIndex, int idButton) const;
	HIMAGELIST SetDisableImageList(HIMAGELIST himlNewDisabled) const;
	DWORD SetDrawTextFlags(DWORD dwMask, DWORD dwDTFlags) const;
	DWORD SetExtendedStyle(DWORD dwExStyle) const;
	HIMAGELIST SetHotImageList(HIMAGELIST himlNewHot) const;
	int   SetHotItem(int iHot) const;
	HIMAGELIST SetImageList(HIMAGELIST himlNew) const;
	BOOL  SetIndent(int iIndent) const;
	BOOL  SetMaxTextRows(int iMaxRows) const;
	BOOL  SetPadding(int cx, int cy) const;
	void  SetToolTips(CToolTip* pToolTip) const;

	// Attributes
	std::vector<UINT>& GetToolBarData() const {return (std::vector <UINT> &)m_vToolBarData;}
	ToolBarTheme& GetToolBarTheme() {return m_Theme;}
	void SetToolBarTheme(ToolBarTheme& Theme);

protected:
// Overridables
	virtual void OnCreate();
	virtual void OnDestroy();
	virtual void OnWindowPosChanging(WPARAM wParam, LPARAM lParam);
	virtual LRESULT OnCustomDraw(NMHDR* pNMHDR);
	virtual LRESULT OnNotifyReflect(WPARAM wParam, LPARAM lParam);
	virtual void PreCreate(CREATESTRUCT &cs);
	virtual void PreRegisterClass(WNDCLASS &wc);
	virtual LRESULT WndProcDefault(UINT uMsg, WPARAM wParam, LPARAM lParam);

private:
	CToolBar(const CToolBar&);				// Disable copy construction
	CToolBar& operator = (const CToolBar&); // Disable assignment operator

	std::vector<UINT> m_vToolBarData;	// vector of resource IDs for toolbar buttons
	std::map<CString, int> m_StringMap;	// a map of strings used in SetButtonText
	UINT m_OldToolBarID;				// Bitmap Resource ID, used in AddBitmap/ReplaceBitmap
	ToolBarTheme m_Theme;				// The theme structure
	BOOL m_bDrawArrowBkgrnd;			// True if a seperate arrow background is to be drawn

};  // class CToolBar
