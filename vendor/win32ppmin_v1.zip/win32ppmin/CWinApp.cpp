#include "CWinApp.h"
#include "CWinException.h"
#include "CWnd.h"
#include "menu.h"

CWinApp::CWinApp() : m_Callback(NULL), m_hAccel(0), m_pWndAccel(0)
{
	try
	{
		m_csAppStart.Lock();
		assert( 0 == SetnGetThis() );	// Test if this is the first instance of CWinApp

		m_dwTlsIndex = ::TlsAlloc();
		if (m_dwTlsIndex == TLS_OUT_OF_INDEXES)
		{
			// We only get here in the unlikely event that all TLS indexes are already allocated by this app
			// At least 64 TLS indexes per process are allowed. Win32++ requires only one TLS index.
			m_csAppStart.Release();
			throw CWinException(_T("CWinApp::CWinApp  Failed to allocate TLS Index"));
		}

		SetnGetThis(this);
		m_csAppStart.Release();

		// Set the instance handle
#ifdef _WIN32_WCE
		m_hInstance = (HINSTANCE)GetModuleHandle(0);
#else
		MEMORY_BASIC_INFORMATION mbi = {0};
		VirtualQuery( (LPCVOID)SetnGetThis, &mbi, sizeof(mbi) );
		assert(mbi.AllocationBase);
		m_hInstance = (HINSTANCE)mbi.AllocationBase;
#endif

		m_hResource = m_hInstance;
		SetCallback();

		// Assign the special CWnds used by SetWindowPos
		m_csMapLock.Lock();
		m_mapHWND.insert(std::make_pair(HWND_TOP, (CWnd*)&wndTop));
		m_mapHWND.insert(std::make_pair(HWND_TOPMOST, (CWnd*)&wndTopMost));
		m_mapHWND.insert(std::make_pair(HWND_NOTOPMOST, (CWnd*)&wndNoTopMost));
		m_mapHWND.insert(std::make_pair(HWND_BOTTOM, (CWnd*)&wndBottom));
		GetApp()->m_csMapLock.Release();
	}

	catch (const CWinException &e)
	{
		e.what();
		throw;
	}
}

CWinApp::~CWinApp()
{
	std::vector<TLSDataPtr>::iterator iter;
	for (iter = m_vTLSData.begin(); iter < m_vTLSData.end(); ++iter)
	{
		(*iter)->vTmpDCs.clear();
#ifndef _WIN32_WCE
		(*iter)->vTmpMenus.clear();
#endif
		(*iter)->vTmpWnds.clear();
	}

	// Check that all CWnd windows are destroyed
	std::map<HWND, CWnd*, CompareHWND>::iterator m;
	for (m = m_mapHWND.begin(); m != m_mapHWND.end(); ++m)
	{
		HWND hWnd = (*m).first;
		if (::IsWindow(hWnd))
			::DestroyWindow(hWnd);
	}
	m_mapHWND.clear();
	m_mapGDI.clear();
	m_mapHDC.clear();
	m_mapHMENU.clear();

	// Do remaining tidy up
	if (m_dwTlsIndex != TLS_OUT_OF_INDEXES)
	{
		::TlsSetValue(GetTlsIndex(), NULL);
		::TlsFree(m_dwTlsIndex);
	}

	SetnGetThis((CWinApp*)-1);
}

void CWinApp::AddTmpDC(CDC* pDC)
{
	// The TmpMenus are created by GetSybMenu.
	// They are removed by CleanupTemps
	assert(pDC);

	// Ensure this thread has the TLS index set
	TLSData* pTLSData = GetApp()->SetTlsIndex();
	pTLSData->vTmpDCs.push_back(pDC); // save pDC as a smart pointer
}

void CWinApp::AddTmpGDI(CGDIObject* pObject)
{
	// The temporary CGDIObjects are removed by CleanupTemps
	assert(pObject);

	// Ensure this thread has the TLS index set
	TLSData* pTLSData = GetApp()->SetTlsIndex();
	pTLSData->vTmpGDIs.push_back(pObject); // save pObject as a smart pointer
}

#ifndef _WIN32_WCE
CMenu* CWinApp::AddTmpMenu(HMENU hMenu)
{
	// The TmpMenus are created by GetSybMenu.
	// They are removed by CleanupTemps
	assert(::IsMenu(hMenu));
	assert(!GetCMenuFromMap(hMenu));

	CMenu* pMenu = new CMenu;
	pMenu->m_hMenu = hMenu;
	m_csMapLock.Lock();
	m_mapHMENU.insert(std::make_pair(hMenu, pMenu));
	m_csMapLock.Release();
	pMenu->m_IsTmpMenu = TRUE;

	// Ensure this thread has the TLS index set
	TLSData* pTLSData = GetApp()->SetTlsIndex();
	pTLSData->vTmpMenus.push_back(pMenu); // save pMenu as a smart pointer
	return pMenu;
}
#endif

CWnd* CWinApp::AddTmpWnd(HWND hWnd)
{
	// TmpWnds are created if required to support functions like CWnd::GetParent.
	// They are removed by CleanupTemps
//	assert(::IsWindow(hWnd));
	assert(!GetCWndFromMap(hWnd));

	CWnd* pWnd = new CWnd;
	pWnd->m_hWnd = hWnd;
	pWnd->AddToMap();
	pWnd->m_IsTmpWnd = TRUE;

	// Ensure this thread has the TLS index set
	TLSData* pTLSData = GetApp()->SetTlsIndex();
	pTLSData->vTmpWnds.push_back(pWnd); // save pWnd as a smart pointer
	return pWnd;
}

void CWinApp::CleanupTemps()
// Removes all Temporary CWnds and CMenus belonging to this thread
{
	// Retrieve the pointer to the TLS Data
	TLSData* pTLSData = (TLSData*)TlsGetValue(GetApp()->GetTlsIndex());
	assert(pTLSData);

	pTLSData->vTmpDCs.clear();
	pTLSData->vTmpGDIs.clear();
	pTLSData->vTmpWnds.clear();


#ifndef _WIN32_WCE
	pTLSData->vTmpMenus.clear();
#endif
}

CDC* CWinApp::GetCDCFromMap(HDC hDC)
{
	// Allocate an iterator for our HWND map
	std::map<HDC, CDC*, CompareHDC>::iterator m;

	// Find the CDC pointer mapped to this HDC
	CDC* pDC = 0;
	m_csMapLock.Lock();
	m = m_mapHDC.find(hDC);

	if (m != m_mapHDC.end())
		pDC = m->second;

	m_csMapLock.Release();
	return pDC;
}

CGDIObject* CWinApp::GetCGDIObjectFromMap(HGDIOBJ hObject)
{
	// Allocate an iterator for our HWND map
	std::map<HGDIOBJ, CGDIObject*, CompareGDI>::iterator m;

	// Find the CGDIObject pointer mapped to this HGDIOBJ
	CGDIObject* pObject = 0;
	m_csMapLock.Lock();
	m = m_mapGDI.find(hObject);

	if (m != m_mapGDI.end())
		pObject = m->second;

	m_csMapLock.Release();
	return pObject;
}

CMenu* CWinApp::GetCMenuFromMap(HMENU hMenu)
{
	std::map<HMENU, CMenu*, CompareHMENU>::iterator m;

	// Find the CMenu pointer mapped to this HMENU
	CMenu* pMenu = 0;
	m_csMapLock.Lock();
	m = m_mapHMENU.find(hMenu);

	if (m != m_mapHMENU.end())
		pMenu = m->second;

	m_csMapLock.Release();
	return pMenu;
}

CWnd* CWinApp::GetCWndFromMap(HWND hWnd)
{
	// Allocate an iterator for our HWND map
	std::map<HWND, CWnd*, CompareHWND>::iterator m;

	// Find the CWnd pointer mapped to this HWND
	CWnd* pWnd = 0;
	m_csMapLock.Lock();
	m = m_mapHWND.find(hWnd);

	if (m != m_mapHWND.end())
		pWnd = m->second;

	m_csMapLock.Release();
	return pWnd;
}

BOOL CWinApp::InitInstance()
{
	// InitInstance contains the initialization code for your application
	// You should override this function with the code to run when the application starts.

	// return TRUE to indicate success. FALSE will end the application
	return TRUE;
}

int CWinApp::MessageLoop()
{
	// This gets any messages queued for the application, and dispatches them.
	MSG Msg = {0};
	int status = 1;
	LONG lCount = 0;

	while (status != 0)
	{
		// While idle, perform idle processing until OnIdle returns FALSE
		while (!::PeekMessage(&Msg, 0, 0, 0, PM_NOREMOVE) && OnIdle(lCount) == TRUE)
		{
			++lCount;
		}

		lCount = 0;

		// Now wait until we get a message
		if ((status = ::GetMessage(&Msg, NULL, 0, 0)) == -1)
			return -1;

		if (!PreTranslateMessage(Msg))
		{
			::TranslateMessage(&Msg);
			::DispatchMessage(&Msg);
		}
	}

	return LOWORD(Msg.wParam);
}

BOOL CWinApp::OnIdle(LONG lCount)
{
	if (lCount == 0)
		CleanupTemps();

	return FALSE;
}

BOOL CWinApp::PreTranslateMessage(MSG Msg)
{
	// This functions is called by the MessageLoop. It processes the
	// keyboard accelerator keys and calls CWnd::PreTranslateMessage for
	// keyboard and mouse events.

	BOOL Processed = FALSE;

	// only pre-translate mouse and keyboard input events
	if ((Msg.message >= WM_KEYFIRST && Msg.message <= WM_KEYLAST) ||
		(Msg.message >= WM_MOUSEFIRST && Msg.message <= WM_MOUSELAST))
	{
		// Process keyboard accelerators
		if (m_pWndAccel && ::TranslateAccelerator(*m_pWndAccel, m_hAccel, &Msg))
			Processed = TRUE;
		else
		{
			// Search the chain of parents for pretranslated messages.
			for (HWND hWnd = Msg.hwnd; hWnd != NULL; hWnd = ::GetParent(hWnd))
			{
				CWnd* pWnd = GetCWndFromMap(hWnd);
				if (pWnd)
				{
					Processed = pWnd->PreTranslateMessage(&Msg);
					if(Processed)
						break;
				}
			}
		}
	}

	return Processed;
}

int CWinApp::Run()
{
	// InitInstance runs the App's initialization code
	if (InitInstance())
	{
		// Dispatch the window messages
		return MessageLoop();
	}
	else
	{
		TRACE(_T("InitInstance failed!  Terminating program\n"));
		::PostQuitMessage(-1);
		return -1;
	}
}

void CWinApp::SetAccelerators(HACCEL hAccel, CWnd* pWndAccel)
// nID is the resource ID of the accelerator table
// pWndAccel is the window pointer for translated messages
{
	assert (hAccel);
	assert (pWndAccel);

	m_pWndAccel = pWndAccel;
	m_hAccel = hAccel;
}

void CWinApp::SetCallback()
{
	// Registers a temporary window class so we can get the callback
	// address of CWnd::StaticWindowProc.
	// This technique works for all Window versions, including WinCE.

	WNDCLASS wcDefault = {0};

	LPCTSTR szClassName		= _T("Win32++ Temporary Window Class");
	wcDefault.hInstance		= GetInstanceHandle();
	wcDefault.lpfnWndProc	= CWnd::StaticWindowProc;
	wcDefault.lpszClassName = szClassName;

	::RegisterClass(&wcDefault);

	// Retrieve the class information
	ZeroMemory(&wcDefault, sizeof(wcDefault));
	::GetClassInfo(GetInstanceHandle(), szClassName, &wcDefault);

	// Save the callback address of CWnd::StaticWindowProc
	assert(wcDefault.lpfnWndProc);	// Assert fails when running UNICODE build on ANSI OS.
	m_Callback = wcDefault.lpfnWndProc;
	::UnregisterClass(szClassName, GetInstanceHandle());
}

CWinApp* CWinApp::SetnGetThis(CWinApp* pThis /*= 0*/)
{
	// This function stores the 'this' pointer in a static variable.
	// Once stored, it can be used later to return the 'this' pointer.
	// CWinApp's Destructor calls this function with a value of -1.

	static CWinApp* pWinApp = 0;

	if ((CWinApp*)-1 == pThis)
		pWinApp = 0;
	else if (0 == pWinApp)
		pWinApp = pThis;

	return pWinApp;
}

void CWinApp::SetResourceHandle(HINSTANCE hResource)
{
	// This function can be used to load a resource dll.
	// A resource dll can be used to define resources in different languages.
	// To use this function, place code like this in InitInstance
	//
	// HINSTANCE hResource = LoadLibrary(_T("MyResourceDLL.dll"));
	// SetResourceHandle(hResource);
	m_hResource = hResource;
}

TLSData* CWinApp::SetTlsIndex()
{
	TLSData* pTLSData = (TLSData*)::TlsGetValue(GetTlsIndex());
	if (NULL == pTLSData)
	{
		pTLSData = new TLSData;
		
		m_csTLSLock.Lock();
		m_vTLSData.push_back(pTLSData);	// store as a Shared_Ptr
		m_csTLSLock.Release();
		
		::TlsSetValue(GetTlsIndex(), pTLSData);
	}
	return pTLSData;
}
