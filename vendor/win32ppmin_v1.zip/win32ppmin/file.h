#pragma once

#include "wincore_head.h"
#include "cstring.h"

class CFile
{
public:
	CFile();
	CFile(HANDLE hFile);
	CFile(LPCTSTR pszFileName, UINT nOpenFlags);
	~CFile();
	operator HANDLE() const;

	BOOL Close();
	BOOL Flush();
	HANDLE GetHandle() const;
	ULONGLONG GetLength() const;
	const CString& GetFileName() const;
	const CString& GetFilePath() const;
	const CString& GetFileTitle() const;
	ULONGLONG GetPosition() const;
	BOOL LockRange(ULONGLONG Pos, ULONGLONG Count);
	BOOL Open(LPCTSTR pszFileName, UINT nOpenFlags);
	CString OpenFileDialog(LPCTSTR pszFilePathName = NULL,
					DWORD dwFlags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, LPCTSTR pszFilter = NULL,
					CWnd* pOwnerWnd = NULL);
	UINT Read(void* pBuf, UINT nCount);
	static BOOL Remove(LPCTSTR pszFileName);
	static BOOL Rename(LPCTSTR pszOldName, LPCTSTR pszNewName);
	CString SaveFileDialog(LPCTSTR pszFilePathName = NULL,
					DWORD dwFlags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, LPCTSTR pszFilter = NULL,
					LPCTSTR pszDefExt = NULL, CWnd* pOwnerWnd = NULL);
	ULONGLONG Seek(LONGLONG lOff, UINT nFrom);
	void SeekToBegin();
	ULONGLONG SeekToEnd();
	void SetFilePath(LPCTSTR pszNewName);
	BOOL SetLength(ULONGLONG NewLen);
	BOOL UnlockRange(ULONGLONG Pos, ULONGLONG Count);
	BOOL Write(const void* pBuf, UINT nCount);

private:
	CFile(const CFile&);				// Disable copy construction
	CFile& operator = (const CFile&);	// Disable assignment operator
	CString m_FileName;
	CString m_FilePath;
	CString m_FileTitle;
	HANDLE m_hFile;
};
